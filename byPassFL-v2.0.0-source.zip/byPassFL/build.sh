#!/usr/bin/env bash
# Portable device build. Always resolve the workspace relative to this script.
BYPASSFL_PROJECT_DIR=$(cd "$(dirname "$0")" && pwd) || exit 1
exec python3 -B "$BYPASSFL_PROJECT_DIR/tools/build/build.py" "$@"

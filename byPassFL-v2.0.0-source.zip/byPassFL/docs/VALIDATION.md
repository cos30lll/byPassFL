# 2.0.0 验证记录

- Java 8 目标字节码、JDK17 编译通过，源码与官方 libxposed API 102 ABI 一致。
- 设备离线完整 APK 构建通过，`BUILD_RC=0`。
- apksigner 确认 APK v2/v3 签名通过；本地调试签名，不使用旧工程私钥。
- 编译后 Manifest 确认为 `com.fl.bypass` / 2.0.0 / versionCode 10。
- Xposed 入口 `com.fl.bypass.ByPassModule`；默认作用域保持 `com.lerist.fakelocation`。
- 主 DEX 中没有 libxposed API 类定义或旧模块类定义；组件 DEX 使用新的辅助类包名。
- 23 项后端资源逐项哈希、大小和 native 内容绑定核验通过。native 可执行段未改变。
- 组件排除谓词、两条调用方和手动应用范围的最小 DEX 检查通过。
- 固定 ABI 证据按功能整理到 `docs/abi/`。本次不更改宿主类名/方法签名。
- 源码包采用允许清单及逐文件 SHA-256，排除私钥、账号缓存、个人日志、分析快照和第三方后端二进制。

本机 Gradle Wrapper 分发下载曾超时，直用已有 Gradle 的离线尝试因缺少 AGP 8.5.2 缓存失败，在线尝试也因依赖下载超时已取消；因此本轮不宣称标准 Gradle 完整构建已经通过。项目提供固定版本配置和 CI 入口；设备离线成品构建已实际通过。

运行期功能为待用户实机验收。没有启动 Fake Location、附加进程、操作界面、读取 UI 层级、注入故障或重启设备。

机器可读报告在本地 `build/reports/`，构建日志在 `build/offline-build.log`。发布源码不包含这些带本机路径的日志。

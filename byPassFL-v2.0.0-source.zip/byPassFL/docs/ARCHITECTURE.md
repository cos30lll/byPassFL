# 架构与维护边界

本工程保持一个 Android Gradle 应用模块，按功能职责分包；注入组件的辅助源码单独放在 `component/`。不为目录分层引入空接口、依赖注入框架或多余 Gradle 子模块。

```mermaid
flowchart TD
    Entry[ByPassModule] --> Lifecycle[ApplicationLifecycleHooks]
    Entry --> Coordinator[HostHooks]
    Lifecycle --> Coordinator
    Coordinator --> Gates[FeatureGateHooks]
    Coordinator --> Root[RootStartHooks]
    Coordinator --> Runtime[MockRuntimeHooks]
    Coordinator --> Cell[CellSimulationHooks]
    Root --> Bootstrap[BackendBootstrap]
    Bootstrap --> Assets[BackendAssets]
    Bootstrap --> Payload[PayloadHooks]
    Payload --> State[ComponentState]
    Runtime --> Session[MockSession]
    Runtime --> Binding[ServiceBindings]
    Runtime --> Route[RouteHooks]
    Runtime --> Policy[PolicyHooks]
```

## 职责

| 位置 | 负责的行为 | 不应承担的职责 |
| --- | --- | --- |
| `ByPassModule` | 选择宿主、记录进程身份、创建装配器 | 文件、网络或模拟业务 |
| `hook/HostHooks` | 按原时序安装各功能组，主进程边界 | 实际 Hook 拦截逻辑 |
| `hook/ApplicationLifecycleHooks` | 壳解包后重复尝试安装、Application 回调 | 功能资格判断 |
| `hook/FeatureGateHooks` | 客户端资格、期限、调用者去优化 | Root 引导、会话和路线状态 |
| `hook/RootStartHooks` | Root 启动等待与失败后的 UI 恢复 | 资源哈希、资源格式解析 |
| `backend/BackendBootstrap` | 异步排队、重试、类加载与引导状态 | 资源读写实现、载荷 Hook 详情 |
| `backend/BackendAssets` | SHA-256、私有目录边界、原子替换、缓存 | 宿主 UI 或模拟状态 |
| `backend/PayloadHooks` | 固定载荷 ABI 的安装与 native 诊断 | 会话恢复控制 |
| `backend/ComponentState` | 真实 Binder 版本查询、服务通道选择 | 用户提示渲染 |
| `runtime/MockRuntimeHooks` | 连接运行期功能、处理宿主 Binder 缓存 | 路线事件和基站回包详情 |
| `runtime/session/MockSession` | 用户运行意图、真实状态、有界恢复和设置重放 | 伪造状态返回值 |
| `runtime/service/ServiceBindings` | 绑定、连接回调、失败重试、解绑 | 随意接受外部服务 Intent |
| `runtime/route/RouteHooks` | 暂停、恢复计时、停止、完成 | 启动定位组件 |
| `runtime/policy/PolicyHooks` | 策略检查和线程作用域适配 | 修改手动模拟应用范围 |
| `runtime/cell/CellSimulationHooks` | 开关意图、查询上下文、缓存和 UI 同步 | 合成基站数据 |
| `core/HookRegistry` | 成功后去重、稳定 Hook ID、去优化登记 | 决定业务返回值 |
| `core/Reflector` | 原始方法查找、字段访问、异常解包 | 猜测混淆类名 |
| `host/HostAbi` | 当前固定版本的共享类型/服务常量 | 跨版本推测匹配 |

## 依赖方向

业务对象接受 `XposedModule`，不再依赖入口类 `ByPassModule`。`backend` 与 `runtime` 的共同能力放在 `host`/`core`，双方没有相互持有的循环依赖。`ModuleInfo` 为构建生成的常量类，配置来自 `module.properties`。

Hook 登记按功能组隔离。重复生命周期事件只尝试未完成目标；安装成功后再登记，避免失败目标被提前标记。API 102 参数替换通过新数组 `proceed(args)` 完成，不修改只读参数列表。

## 状态与并发

- 后端引导的排队位使用 `AtomicBoolean`；加载与启动前准备串行，失败按固定间隔重试。
- 会话方法使用对象监视器管理运行意图、暂停、重放和恢复窗口。手动停止/暂停保留优先级；权限错误撤销恢复。
- 每个服务绑定对象管理自己的回调状态；等待仅在非主线程发生，保持原来的有界等待。
- 基站请求使用 sequence/generation 避免迟到回包夺回用户手动关闭的选择；数据仍来自真实缓存或宿主在线查询。
- 用户提示统一在主线程投递并限频；无自动设备或框架重启。

## 版本适配

当前仅声明 `1.5.2 / 1702`。复杂成员名保留原始 Unicode，相关证据在 `docs/abi/`。新增版本应新增独立适配记录，先核验签名，再修改对应功能组；不通过粗略类名猜测扩大作用域。

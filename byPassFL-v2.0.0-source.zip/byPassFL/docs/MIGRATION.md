# 从校ecmod迁移到 byPassFL

| 项目 | 旧值 | 新值 |
| --- | --- | --- |
| 显示名 | 校ecmod | byPassFL |
| applicationId / Java namespace | com.ds.ecmod | com.fl.bypass |
| Xposed 入口 | com.ds.ecmod.MainModule | com.fl.bypass.ByPassModule |
| Activity | com.ds.ecmod.MainActivity | com.fl.bypass.ui.LauncherActivity |
| 组件辅助类 | com.ds.ecmod.backend.ComponentVersion | com.fl.bypass.component.ComponentVersion |
| 日志标签 | SchoolECMod / SchoolECModBackend | ByPassFL / ByPassFLBackend |
| 模块版本 | 1.2.6 / 9 | 2.0.0 / 10 |
| 定位组件版本 | 5 | 5 |
| 宿主私有缓存目录 | school_ecmod/backend | bypassfl/backend |

包名改变后 Android 将新包视为独立应用。原工程保留为回滚基线；新包不覆盖旧包，不自动删除旧缓存。用户在 LSPosed 中调整模块启用与作用域，避免两个模块同时安装同一批 Hook。

组件 5 的协议保持一致，辅助类重命名本身不扩展业务功能。不自动替换 system_server 驻留组件；如检查结果明确提示旧组件，再由用户自行决定重启。实际定位和基站结果继续按实机验收。

本次工作只完成源码、构建和发布准备，没有安装、启用、卸载模块，没有重启目标应用、框架或设备。

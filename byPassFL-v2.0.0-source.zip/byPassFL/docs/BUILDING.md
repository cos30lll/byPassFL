# 构建与发布

## 环境

JDK 17、Python 3、Android SDK `platforms;android-34` 和 `build-tools;35.0.0`。标准构建固定 Gradle 8.7 / Android Gradle Plugin 8.5.2。Gradle Wrapper 带官方分发 SHA-256，API AAR 带固定哈希校验。

`module.properties` 是唯一身份配置。版本类、Xposed 入口/作用域/描述在 `build/` 下生成；请勿把生成结果复制回源码。

## 本地后端依赖

按照 [backend/README.md](../backend/README.md) 准备原始 DEX 与 native assets，再运行后端生成。依赖哈希、定位组件绑定和文件清单均写入构建报告。

本地已有资源的工作区可直接构建。GitHub 源码包需要准备二进制依赖才能构建完整可运行 APK。CI 源码编译任务不依赖运行时后端，不交付缺少后端的 APK。

## 设备离线构建

```sh
export BYPASSFL_SDK=/path/to/android-sdk
bash build.sh
```

流程：后端核验 → 生成元数据 → javac → D8 → aapt2 → zipalign → debug 签名 → 最终 APK 核验。所有输出只在 `build/` 与 `dist/`；旧 APK、旧签名密钥不作为默认输入。

当前 Android 设备上的 zipalign 为非匹配架构，debug 构建记录 `zipaligned=false`。发布签名入口要求可运行的 zipalign，否则明确终止，避免把设备测试包误标为发布包。

```sh
bash build.sh --unsigned
export BYPASSFL_STORE_PASSWORD='your-store-password'
export BYPASSFL_KEY_PASSWORD='your-key-password'
bash build.sh --keystore /private/path/release.jks --alias your-alias
```

发布口令只通过环境变量传给 apksigner，不存入项目。`build/signing/debug.keystore` 是本地调试密钥，发布源码包明确排除。

## Gradle / Android Studio

```sh
bash gradlew :app:assembleDebug
```

可通过 `local.properties` 的 `sdk.dir` 指定 SDK，或使用标准 `ANDROID_HOME`。AGP 负责对齐与调试签名。构建结果在 `app/build/outputs/apk/`。

源码编译任务：

```sh
bash gradlew :app:compileDebugJavaWithJavac
```

该任务用于公开源码 CI。完整运行需要本地后端资源，CI 不包含设备动态验证。

## 发布文件

```sh
python3 -B tools/release/package_source.py
```

输出 `dist/byPassFL-v2.0.0-source.zip`、`dist/source-manifest.json` 与 `dist/SOURCE-SHA256.txt`。允许清单包含项目源码、构建入口、ABI 文档、模板、编译 API 和依赖说明。逐文件哈希在 ZIP 回读后核验。

# 第三方组件

本项目 MIT 许可覆盖项目自有 Java/Python 源码与文档。第三方 API、工具和目标应用二进制各自保留其许可及权利，不因为存在于本地工作区而被重新许可。

| 组件 | 使用方式 | 项目中的位置 |
| --- | --- | --- |
| libxposed API 102.0.0 | 官方 compileOnly ABI | libs/compile-only/libxposed-api-102.0.0.aar |
| Gradle 8.7 Wrapper | 构建启动器 | gradle/wrapper/gradle-wrapper.jar |
| Android SDK / AGP | 外部构建工具 | 用户 SDK / Gradle 下载 |
| JADX 1.5.6 / dexlib2 | 本地 DEX 重建工具，不随源码包分发完整工具 JAR | BYPASSFL_DEXLIB_JAR |
| Fake Location 1.5.2 / 1702 | 本地原始 DEX/native 及派生后端，不随公开源码包分发 | backend/inputs 与 app/src/main/assets/backend |

官方链接：

- https://github.com/libxposed/api
- https://github.com/gradle/gradle
- https://github.com/skylot/jadx

源码发布包包含官方 API 编译文件与 Gradle Wrapper，并保留对应许可说明；第三方运行时后端通过本地导入步骤准备。项目未声称掌握目标应用第三方二进制的原始源码。

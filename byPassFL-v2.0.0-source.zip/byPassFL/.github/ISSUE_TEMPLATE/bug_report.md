---
name: Bug report
about: Report a module failure with precise runtime evidence
title: ''
labels: bug
---

模块版本 / Android / LSPosed / 目标应用版本：

触发步骤与用户实际观察：

预期结果：

实际结果：

脱敏后的 ByPassFL / ByPassFLBackend 相关日志：

是否涉及手动暂停、停止、路线完成或组件版本提示：

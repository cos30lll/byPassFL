# libxposed compile-only API

官方 `io.github.libxposed:api:102.0.0` AAR，只参与编译。源码包保留该离线依赖，构建从 AAR 提取 `classes.jar`，主 DEX 输入仅限项目编译类。

SHA-256：`423484a6e1807e7a423c4b88fcd8176d104318259d91791877fed88fe91479d0`。

上游与许可：https://github.com/libxposed/api 。

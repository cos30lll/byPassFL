# byPassFL

针对 Fake Location **1.5.2 / 1702** 的独立 LSPosed 模块。安装包及 Java 命名空间统一为 `com.fl.bypass`，使用官方 libxposed modern API **102**，最低支持 Android **8.0**。当前源码版本 **2.0.0**，定位组件版本 **5**。

项目源自“校ecmod”1.2.6。2.0.0 完成身份迁移、职责拆分、构建标准化和开源目录整理，沿用原有功能调用链。真实定位、路线和基站效果须由用户实机验证；编译、Hook 安装日志和状态返回值不能替代效果验收。

## 项目结构

```text
app/                         Android 模块、入口与宿主运行逻辑
  src/main/java/com/fl/bypass/
    ByPassModule.java        Xposed 入口
    hook/                    生命周期、装配、功能资格、Root 启动
    host/                    固定版本 ABI、后端读取、线程作用域
    backend/                 内置资源、引导状态、组件连接、载荷 Hook
    runtime/                 会话、服务、路线、策略与基站功能
    core/                    Hook 登记、反射、用户提示
    ui/                      模块信息页
component/                   注入组件的项目自有辅助源码
backend/                     本地依赖说明与输入哈希清单
tools/                       config / build / backend / verify / release
docs/                        架构、构建、迁移、验证与 ABI 证据
.github/                     CI、Issue 和 Pull Request 模板
module.properties            名称、包名、版本和兼容范围的唯一配置源
```

## 构建

准备 JDK 17、Python 3、Android SDK 34、Build Tools 35.0.0。仓库包含官方 libxposed 编译依赖，不需要旧 Xposed API。后端的原始 DEX/native 由构建者本地提供，GitHub 源码包不包含这些第三方二进制；准备步骤见 [构建说明](docs/BUILDING.md) 和 [后端依赖](backend/README.md)。

已有本地资源时：

```sh
export BYPASSFL_SDK=/path/to/android-sdk
bash build.sh
```

输出位于 `dist/byPassFL-v2.0.0-debug.apk`。调试签名保存在忽略的 `build/signing/`；正式签名通过显式 `--keystore` 和环境变量传入，不在源码中保存发布口令。

标准 Android Studio / Gradle 入口：

```sh
bash gradlew :app:assembleDebug
```

生成的版本类与 Xposed 元数据均来自 `module.properties`。设备离线构建已经通过；当前设备的 Gradle 分发下载/依赖缓存限制及验证状态见 [验证记录](docs/VALIDATION.md)。CI 负责源码编译检查，实机功能由用户验证。

## 使用与迁移

安装后在 LSPosed 中启用 **byPassFL**，作用域设为 `com.lerist.fakelocation`。包名变化后系统将其视为新应用；旧模块与新模块需要避免同时作用于同一宿主。此项目不会自动卸载旧模块、修改框架数据库或重启设备。详见 [迁移说明](docs/MIGRATION.md)。

日志标签：`ByPassFL`、`ByPassFLBackend`。`HOOK_INSTALLED` 表示安装，`HOOK_HIT` 表示调用，定位结果由目标应用实际收到的坐标与路线判断。

## 贡献和发布

阅读 [架构说明](docs/ARCHITECTURE.md) 与 [贡献规范](CONTRIBUTING.md)。新增宿主适配须保留对应版本 ABI 证据；运行时查找使用原始 Unicode 名称。

生成 GitHub 上传源码包：

```sh
python3 -B tools/release/package_source.py
```

脚本使用允许清单，附带逐文件 SHA-256，排除账号缓存、分析目录、私有日志、签名密钥、构建缓存、APK 和第三方后端二进制。请使用 `dist/*-source.zip` 或遵循 `.gitignore` 提交源码。

项目自有源码采用 [MIT License](LICENSE)；第三方依赖信息见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。

# byPassFL 工程约束

本工程源于独立“校ecmod”项目，适配 `com.lerist.fakelocation` 1.5.2 / 1702；与学习通 ECMod 不同，不套用其维护 Skill 或源码。

名称、applicationId、版本和作用域统一由 `module.properties` 维护。项目依赖 libxposed API 102，仅编译使用，不进入主 DEX。原始 Unicode 反射名称须有 `docs/abi/` 中当前版本证据。

按 `docs/ARCHITECTURE.md` 维护职责和依赖方向。新功能不要堆入 `ByPassModule`。后端副本在 `app/src/main/assets/backend`，原始输入在被忽略的 `backend/inputs`。更新辅助类后同步重建后端、native 绑定和 manifest。

默认动态验证由用户操作。继续修复/完成任务不构成启动授权。不截图、不读取 XML/UI/JSON 层级。手机/框架重启、卸载、修改 LSPosed 数据库和模块启用状态须有用户明确授权。用户要求停止时立即停止全部工具调用；工具长期无回执不重提同类调用。

构建入口 `build.sh` 与 `gradlew`；元数据共用 `tools/config/generate.py`。产物在 `build/`、`dist/`。发布用 `tools/release/package_source.py` 允许清单，不打包整个工作区。

保留手动模拟应用范围、手动停止/暂停、路线完成、权限错误处理。基站数据只取真实缓存或原查询。效果以用户实机为准，日志、返回值与状态不能替代验收。

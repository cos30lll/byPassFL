package com.fl.bypass.component;

import android.content.Context;
import android.os.Parcel;
import android.util.Log;

/** 加入内置 jed2 的只读版本事务；不改变已有 AIDL 的事务号或状态。 */
public final class ComponentVersion {
    private ComponentVersion() {}

    public static final int TRANSACTION = ComponentConfig.TRANSACTION;
    public static final int VERSION = ComponentConfig.VERSION;
    private static final ThreadLocal<String> phase = new ThreadLocal<>();
    private static volatile boolean contextLogged;

    public static boolean dispatch(int code, Parcel data, Parcel reply) {
        if (code != TRANSACTION || reply == null) return false;
        reply.writeNoException();
        reply.writeInt(VERSION);
        return true;
    }

    public static Context requireContext(Context context) {
        if (context == null)
            throw new IllegalStateException("component Context was not initialized");
        if (!contextLogged) {
            contextLogged = true;
            Log.i(
                    "ByPassFLBackend",
                    "CALLER_CONTEXT source=component class=" + context.getClass().getName());
        }
        return context;
    }

    public static void stage(String value) {
        phase.set(value);
    }

    public static void startResult(boolean active) {
        Log.i(
                "ByPassFLBackend",
                "MOCK_START_RESULT active="
                        + active
                        + " phase="
                        + phase.get()
                        + " component="
                        + VERSION
                        + " exclusion_policy=disabled");
        phase.remove();
    }

    public static void startFailed(Throwable error) {
        Log.e(
                "ByPassFLBackend",
                "MOCK_START_FAILED phase=" + phase.get() + " component=" + VERSION,
                error);
        phase.remove();
    }

    public static void logStop(String reason) {
        Log.w("ByPassFLBackend", "MOCK_STOP reason=" + reason + " component=" + VERSION);
    }
}

package com.fl.bypass.hook;

import android.app.Activity;
import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.util.Log;

import com.fl.bypass.ModuleInfo;

import io.github.libxposed.api.XposedModule;

import java.lang.reflect.Method;

/** Lifecycle retries allow shell-protected host DEX to appear without blocking process startup. */
public final class ApplicationLifecycleHooks {
    private final XposedModule module;
    private final HostHooks patches;

    public ApplicationLifecycleHooks(XposedModule module, HostHooks patches) {
        this.module = module;
        this.patches = patches;
    }

    public void install() {
        try {
            Method attach = Application.class.getDeclaredMethod("attach", Context.class);
            module.hook(attach)
                    .intercept(
                            chain -> {
                                Object result = chain.proceed();
                                Application app = (Application) chain.getThisObject();
                                if (app != null
                                        && ModuleInfo.TARGET_PACKAGE.equals(app.getPackageName())) {
                                    patches.install(app.getClassLoader(), "application-attach");
                                }
                                return result;
                            });
        } catch (Throwable error) {
            module.log(Log.ERROR, ModuleInfo.LOG_TAG, "LIFECYCLE_FAILED Application.attach", error);
        }
        try {
            Method create =
                    Instrumentation.class.getDeclaredMethod(
                            "callApplicationOnCreate", Application.class);
            module.hook(create)
                    .intercept(
                            chain -> {
                                Application app = (Application) chain.getArg(0);
                                boolean target =
                                        app != null
                                                && ModuleInfo.TARGET_PACKAGE.equals(
                                                        app.getPackageName());
                                if (target)
                                    patches.install(
                                            app.getClassLoader(), "before-application-onCreate");
                                Object result = chain.proceed();
                                if (target) {
                                    patches.install(
                                            app.getClassLoader(), "after-application-onCreate");
                                    patches.onApplication(app);
                                }
                                return result;
                            });
        } catch (Throwable error) {
            module.log(
                    Log.ERROR,
                    ModuleInfo.LOG_TAG,
                    "LIFECYCLE_FAILED Instrumentation.callApplicationOnCreate",
                    error);
        }
        try {
            Method resume =
                    Instrumentation.class.getDeclaredMethod("callActivityOnResume", Activity.class);
            module.hook(resume)
                    .intercept(
                            chain -> {
                                Object result = chain.proceed();
                                Activity activity = (Activity) chain.getArg(0);
                                if (activity != null
                                        && ModuleInfo.TARGET_PACKAGE.equals(
                                                activity.getPackageName())) {
                                    patches.install(
                                            activity.getClassLoader(), "first-activity-resume");
                                    patches.onApplication(activity.getApplication());
                                }
                                return result;
                            });
        } catch (Throwable error) {
            module.log(
                    Log.ERROR,
                    ModuleInfo.LOG_TAG,
                    "LIFECYCLE_FAILED Instrumentation.callActivityOnResume",
                    error);
        }
        try {
            Class<?> thread = Class.forName("android.app.ActivityThread");
            Application app =
                    (Application) thread.getDeclaredMethod("currentApplication").invoke(null);
            if (app != null && ModuleInfo.TARGET_PACKAGE.equals(app.getPackageName())) {
                patches.install(app.getClassLoader(), "current-application");
                patches.onApplication(app);
            }
        } catch (Throwable ignored) {
            // 冷启动时 currentApplication 为 null 是正常状态。
        }
    }
}

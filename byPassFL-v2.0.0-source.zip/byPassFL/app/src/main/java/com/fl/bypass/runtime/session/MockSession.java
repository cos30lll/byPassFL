package com.fl.bypass.runtime.session;

import android.location.Location;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.backend.ComponentState;

import io.github.libxposed.api.XposedModule;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/** 运行意图与真实后端状态分开记录；状态查询不伪造，停止/权限错误立即撤销恢复。 */
public final class MockSession implements InvocationHandler {
    public interface Connector {
        Object reconnect() throws Throwable;
    }

    public interface Observer {
        void bound(Object remote) throws Throwable;
    }

    private static final int MAX_ATTEMPTS = 8;
    private static final long RECOVERY_WINDOW_MS = 45000;
    private final XposedModule module;
    private final Method start, status, location, setLocation;
    private final Connector connector;
    private final Observer observer;
    private final Object proxy;
    private final LinkedHashMap<String, Call> settings = new LinkedHashMap<>();
    private Object remote;
    private IBinder observed;
    private boolean wanted;
    private boolean suspended;
    private boolean confirmed;
    private Handler monitor;
    private long nextRecovery;
    private long recoveryDeadline;
    private long lastError;
    private int attempts;
    private final Runnable poll = this::poll;

    public MockSession(XposedModule module, Class<?> api, Connector connector, Observer observer)
            throws Exception {
        this.module = module;
        this.connector = connector;
        this.observer = observer;
        start = api.getMethod("ǲ");
        status = api.getMethod("ඇ");
        location = api.getMethod("ೠ");
        setLocation = api.getMethod("Ѭ", Location.class);
        proxy = Proxy.newProxyInstance(api.getClassLoader(), new Class<?>[] {api}, this);
    }

    public synchronized Object wrap(Object value) {
        if (value != proxy) remote = value;
        return value == null ? null : proxy;
    }

    public synchronized boolean owns(Object value) {
        return value == proxy;
    }

    public synchronized boolean wanted() {
        return wanted;
    }

    public synchronized boolean suspended() {
        return suspended;
    }

    public synchronized void rememberLocation(Location value) {
        remember(setLocation, new Object[] {value});
    }

    public synchronized void requestStart(String source) {
        wanted = true;
        suspended = false;
        confirmed = false;
        attempts = 0;
        nextRecovery = 0;
        recoveryDeadline = 0;
        arm();
        info("MOCK_SESSION_REQUESTED source=" + source + " backend_state=pending");
    }

    @Override
    public synchronized Object invoke(Object receiver, Method method, Object[] supplied)
            throws Throwable {
        String name = method.getName();
        Object[] args = supplied == null ? new Object[0] : supplied;
        if (method.getDeclaringClass() == Object.class) {
            if ("equals".equals(name)) return receiver == args[0];
            if ("hashCode".equals(name)) return System.identityHashCode(receiver);
            if ("toString".equals(name)) return "ByPassFL-MockProxy";
        }
        if ("asBinder".equals(name)) return binder(remote);
        boolean starting = "ǲ".equals(name) && args.length == 0;
        boolean stopping = "ઑ".equals(name) && args.length == 0;
        if (starting && !wanted) requestStart("aidl-start");
        if (stopping) {
            cancel("native-stop");
            settings.clear();
        }
        Object result;
        try {
            if (!alive(remote)) remote = connector.reconnect();
            if (remote == null) throw new DeadObjectException();
            if (starting || (!stopping && wanted && method.getReturnType() == void.class))
                observe();
            try {
                result = call(method, remote, args);
            } catch (Throwable error) {
                if (!isDead(error)) throw error;
                remote = connector.reconnect();
                if (remote == null) throw error;
                if (starting || (!stopping && wanted && method.getReturnType() == void.class))
                    observe();
                result = call(method, remote, args);
                info("MOCK_BINDER_RECONNECTED operation=" + name);
            }
        } catch (Throwable error) {
            if (isPermission(error)) cancel("permission-error");
            if (isDead(error) && method.getReturnType() == void.class && !starting && !stopping)
                remember(method, args);
            throw error;
        }
        if (starting) {
            // 状态未就绪不撤销运行意图；真实 AIDL 返回值仍直接交给宿主。
            boolean active = realMocking();
            info("MOCK_START_RETURNED backend_state=" + active);
            if (active && wanted) markHealthy();
        } else if (method.getReturnType() == void.class && !stopping) remember(method, args);
        return result;
    }

    public synchronized boolean healthyOrRecover() {
        if (!wanted || suspended) return realMocking();
        try {
            observe();
            if (alive(remote)
                    && Boolean.TRUE.equals(call(status, remote, new Object[0]))
                    && hasLocation()) {
                markHealthy();
                return true;
            }
            return recover();
        } catch (Throwable error) {
            if (isPermission(error)) cancel("permission-error");
            else if (isDead(error)) remote = null;
            else cancel("status-error");
            error("MOCK_STATUS_FAILED", error);
            return false;
        }
    }

    public synchronized void stopRecovery(String reason) {
        cancel(reason);
        settings.clear();
    }

    public synchronized void suspendRecovery() {
        suspended = true;
        if (monitor != null) monitor.removeCallbacks(poll);
        info("MOCK_RECOVERY_SUSPENDED reason=manual-pause");
    }

    public synchronized void resumeRecovery() {
        suspended = false;
        attempts = 0;
        nextRecovery = 0;
        recoveryDeadline = 0;
        if (wanted) arm();
    }

    private boolean hasLocation() throws Throwable {
        Call last = settings.get("Ѭ");
        if (last == null || last.args.length == 0 || !(last.args[0] instanceof Location))
            return true;
        return call(location, remote, new Object[0]) instanceof Location;
    }

    private boolean realMocking() {
        try {
            return alive(remote) && Boolean.TRUE.equals(call(status, remote, new Object[0]));
        } catch (Throwable error) {
            if (isPermission(error)) cancel("permission-error");
            error("MOCK_STATUS_FAILED", error);
            return false;
        }
    }

    private boolean recover() throws Throwable {
        long now = SystemClock.elapsedRealtime();
        if (!wanted || suspended) return false;
        if (recoveryDeadline == 0) recoveryDeadline = now + RECOVERY_WINDOW_MS;
        if (now >= recoveryDeadline || (now >= nextRecovery && attempts >= MAX_ATTEMPTS)) {
            int used = attempts;
            cancel("recovery-exhausted");
            info("MOCK_RECOVERY_EXHAUSTED attempts=" + used + " window_ms=" + RECOVERY_WINDOW_MS);
            return false;
        }
        if (now < nextRecovery) return false;
        attempts++;
        nextRecovery = now + Math.min(5000, attempts * 1000L);
        Object fresh = connector.reconnect();
        if (fresh == null || !alive(fresh)) {
            info("MOCK_RECOVERY_WAIT attempt=" + attempts + " reason=binder-unavailable");
            return false;
        }
        remote = fresh;
        observe();
        // 重放最后配置；start 后补写最后位置，覆盖后端初始化清空位置的情况。
        for (Call saved : new ArrayList<>(settings.values()))
            call(saved.method, remote, copy(saved.args));
        call(start, remote, new Object[0]);
        Call last = settings.get("Ѭ");
        if (last != null) call(last.method, remote, copy(last.args));
        boolean active = Boolean.TRUE.equals(call(status, remote, new Object[0])) && hasLocation();
        if (active) {
            int used = attempts;
            markHealthy();
            info("MOCK_RECOVERED backend_state=true location_present=true attempts=" + used);
        } else info("MOCK_RECOVERY_WAIT attempt=" + attempts + " reason=backend-state-incomplete");
        return active;
    }

    private void markHealthy() {
        attempts = 0;
        nextRecovery = 0;
        recoveryDeadline = 0;
        if (!confirmed) {
            confirmed = true;
            info("MOCK_SESSION_ACTIVE backend_state=true");
        }
    }

    private void observe() throws Throwable {
        IBinder current = binder(remote);
        if (current == null || current == observed) return;
        try {
            observer.bound(remote);
            observed = current;
        } catch (ComponentState.NotReady error) {
            cancel("component-restart-required");
            throw error;
        } catch (Throwable error) {
            error("MOCK_BACKEND_INSPECT_FAILED", error);
            throw error;
        }
    }

    private void remember(Method method, Object[] args) {
        String name = method.getName(), key = name;
        if ("ਉ".equals(name) && args.length == 1) {
            settings.remove("listener:" + System.identityHashCode(args[0]));
            return;
        }
        if ("ඥ".equals(name) && args.length == 1)
            key = "listener:" + System.identityHashCode(args[0]);
        if ("ȡ".equals(name) || "ઔ".equals(name)) key = "step-state";
        settings.remove(key);
        settings.put(key, new Call(method, copy(args)));
    }

    private void arm() {
        if (monitor == null) {
            HandlerThread thread = new HandlerThread("ByPassFL-Session");
            thread.setDaemon(true);
            thread.start();
            monitor = new Handler(thread.getLooper());
        }
        monitor.removeCallbacks(poll);
        monitor.postDelayed(poll, 2000);
    }

    private void poll() {
        synchronized (this) {
            if (!wanted || suspended) return;
            healthyOrRecover();
            if (wanted && !suspended) monitor.postDelayed(poll, 2000);
        }
    }

    private void cancel(String reason) {
        if (wanted) info("MOCK_SESSION_STOP reason=" + reason);
        wanted = false;
        suspended = false;
        confirmed = false;
        attempts = 0;
        nextRecovery = 0;
        recoveryDeadline = 0;
        if (monitor != null) monitor.removeCallbacks(poll);
    }

    private static Object call(Method method, Object target, Object[] args) throws Throwable {
        try {
            return method.invoke(target, args);
        } catch (InvocationTargetException error) {
            throw error.getCause();
        }
    }

    private static Object[] copy(Object[] args) {
        Object[] next = args.clone();
        for (int i = 0; i < next.length; i++) {
            if (next[i] instanceof Location) {
                Location value = new Location((Location) next[i]);
                value.setTime(System.currentTimeMillis());
                value.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
                next[i] = value;
            } else if (next[i] instanceof java.util.List)
                next[i] = new ArrayList<>((java.util.List<?>) next[i]);
        }
        return next;
    }

    private static IBinder binder(Object target) {
        return target instanceof IInterface ? ((IInterface) target).asBinder() : null;
    }

    private static boolean alive(Object target) {
        IBinder value = binder(target);
        return value != null && value.isBinderAlive();
    }

    public static boolean isPermission(Throwable error) {
        for (int n = 0; error != null && n < 8; n++, error = error.getCause())
            if (error instanceof SecurityException) return true;
        return false;
    }

    private static boolean isDead(Throwable error) {
        for (int n = 0; error != null && n < 8; n++, error = error.getCause())
            if (error instanceof RemoteException) return true;
        return false;
    }

    private void info(String message) {
        module.log(Log.INFO, ModuleInfo.LOG_TAG, message);
    }

    private void error(String message, Throwable error) {
        long now = SystemClock.elapsedRealtime();
        if (lastError != 0 && now - lastError < 10000) return;
        lastError = now;
        module.log(Log.ERROR, ModuleInfo.LOG_TAG, message, error);
    }

    private static final class Call {
        final Method method;
        final Object[] args;

        Call(Method method, Object[] args) {
            this.method = method;
            this.args = args;
        }
    }
}

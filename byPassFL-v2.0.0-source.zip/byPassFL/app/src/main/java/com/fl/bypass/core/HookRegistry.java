package com.fl.bypass.core;

import android.util.Log;

import com.fl.bypass.ModuleInfo;

import io.github.libxposed.api.XposedInterface;
import io.github.libxposed.api.XposedModule;

import java.lang.reflect.Executable;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Set;

/** 每个功能独立登记 Hook；只在安装成功后去重，保留失败后的重试机会。 */
public final class HookRegistry {
    private final XposedModule module;
    private final String group;
    private final Set<Executable> installed = new HashSet<>();
    private final Set<Method> deoptimized = new HashSet<>();

    public HookRegistry(XposedModule module, String group) {
        this.module = module;
        this.group = group;
    }

    public synchronized void attach(Executable target, XposedInterface.Hooker callback) {
        if (installed.contains(target)) return;
        module.hook(target)
                .setId(ModuleInfo.APPLICATION_ID + ":" + group + ":" + target.toString())
                .setExceptionMode(XposedInterface.ExceptionMode.PASSTHROUGH)
                .intercept(callback);
        installed.add(target);
        if (target instanceof Method) deoptimize((Method) target);
        module.log(
                Log.INFO,
                ModuleInfo.LOG_TAG,
                "RUNTIME_HOOK_INSTALLED group="
                        + group
                        + " target="
                        + target.getDeclaringClass().getName()
                        + "."
                        + target.getName());
    }

    public synchronized void deoptimize(Class<?> owner) {
        for (Method method : owner.getDeclaredMethods()) deoptimize(method);
    }

    private void deoptimize(Method method) {
        int flags = method.getModifiers();
        if (Modifier.isAbstract(flags) || Modifier.isNative(flags) || deoptimized.contains(method))
            return;
        if (module.deoptimize(method)) deoptimized.add(method);
    }

    public synchronized int size() {
        return installed.size();
    }
}

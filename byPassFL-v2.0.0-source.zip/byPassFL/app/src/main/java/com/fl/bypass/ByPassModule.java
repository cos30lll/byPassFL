package com.fl.bypass;

import android.util.Log;

import com.fl.bypass.hook.ApplicationLifecycleHooks;
import com.fl.bypass.hook.HostHooks;

import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

/** Modern libxposed entrypoint. It only selects the host and assembles lifecycle hooks. */
public final class ByPassModule extends XposedModule {
    private String processName = "unknown";
    private HostHooks hooks;
    private boolean lifecycleInstalled;

    @Override
    public void onModuleLoaded(XposedModuleInterface.ModuleLoadedParam param) {
        processName = param.getProcessName();
    }

    @Override
    public synchronized void onPackageReady(XposedModuleInterface.PackageReadyParam param) {
        if (!ModuleInfo.TARGET_PACKAGE.equals(param.getPackageName())) return;
        if (hooks == null) hooks = new HostHooks(this, processName);
        log(
                Log.INFO,
                ModuleInfo.LOG_TAG,
                "MODULE_READY version="
                        + ModuleInfo.VERSION_NAME
                        + " target="
                        + ModuleInfo.TARGET_VERSION_NAME
                        + "/"
                        + ModuleInfo.TARGET_VERSION_CODE
                        + " process="
                        + processName
                        + " api="
                        + getApiVersion());
        if (!lifecycleInstalled) {
            lifecycleInstalled = true;
            new ApplicationLifecycleHooks(this, hooks).install();
        }
        hooks.install(param.getClassLoader(), "package-ready");
    }
}

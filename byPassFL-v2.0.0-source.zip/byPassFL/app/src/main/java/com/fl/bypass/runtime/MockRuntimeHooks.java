package com.fl.bypass.runtime;

import static com.fl.bypass.core.Reflector.call;
import static com.fl.bypass.core.Reflector.field;
import static com.fl.bypass.core.Reflector.method;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.IInterface;
import android.util.Log;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.backend.ComponentState;
import com.fl.bypass.core.HookRegistry;
import com.fl.bypass.core.UserNotice;
import com.fl.bypass.host.HostAbi;
import com.fl.bypass.runtime.policy.PolicyHooks;
import com.fl.bypass.runtime.route.RouteHooks;
import com.fl.bypass.runtime.service.ServiceBindings;
import com.fl.bypass.runtime.session.MockSession;

import io.github.libxposed.api.XposedModule;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** 1702 共用运行期修复；对应原始 ABI 存于 docs/abi/runtime-abi.tsv。 */
public final class MockRuntimeHooks {
    private final XposedModule module;
    private final HookRegistry hooks;
    private Field mockRemote, mode, rootRemote;
    private Method mockGetter, rootSingleton, rootGetter;
    private MockSession session;
    private ServiceBindings binding;
    private RouteHooks routes;
    private final PolicyHooks policy;

    public MockRuntimeHooks(XposedModule module) {
        this.module = module;
        this.hooks = new HookRegistry(module, "mock-runtime");
        this.policy = new PolicyHooks(module);
    }

    public synchronized void install(ClassLoader loader) {
        if (loader == null) return;
        try {
            Class<?> mock = Class.forName(HostAbi.PREFIX + "ŒޘŒ", false, loader);
            Class<?> holder = Class.forName(HostAbi.PREFIX + "ओޔओ", false, loader);
            Class<?> api = Class.forName(HostAbi.PREFIX + "ГڵГ", false, loader);
            mockRemote = field(mock, "ඈ");
            mode = field(mock, "ஆ");
            rootRemote = field(holder, "ඈ");
            mockGetter = method(mock, "ʥ");
            rootSingleton = method(holder, "ඈ");
            rootGetter = method(holder, "ஆ");
            if (session == null)
                session =
                        new MockSession(
                                module, api, () -> reconnect(mock, loader), this::inspectBackend);
            installTimeGuard(loader);
            hooks.attach(
                    rootGetter,
                    chain -> {
                        Object target = chain.getThisObject();
                        Object value = rootRemote.get(target);
                        if (value != null && !alive(value)) {
                            rootRemote.set(target, null);
                            info("MOCK_STALE_ROOT_BINDER_CLEARED");
                        }
                        return chain.proceed();
                    });
            hooks.attach(
                    mockGetter,
                    chain -> {
                        Object owner = chain.getThisObject();
                        Object cached = mockRemote.get(owner);
                        if (cached != null && session.owns(cached)) return cached;
                        if (cached != null && !alive(cached)) {
                            mockRemote.set(owner, null);
                            info("MOCK_STALE_BINDER_CLEARED");
                        }
                        Object value = chain.proceed();
                        Object wrapped = session.wrap(value);
                        mockRemote.set(owner, wrapped);
                        return wrapped;
                    });
            // 初次 Binder 缺失时宿主会跳过写入；仍保存用户选定位置供后续真实重连。
            hooks.attach(
                    method(mock, "Ѹ", Location.class),
                    chain -> {
                        Object result = chain.proceed();
                        session.rememberLocation((Location) chain.getArg(0));
                        return result;
                    });
            hooks.attach(
                    method(mock, "Ԝ"),
                    chain -> {
                        session.requestStart("host-start");
                        try {
                            return chain.proceed();
                        } catch (Throwable error) {
                            if (MockSession.isPermission(error))
                                session.stopRecovery("permission-error");
                            throw error;
                        }
                    });
            hooks.attach(
                    method(mock, "എ"),
                    chain -> {
                        session.stopRecovery("host-stop");
                        info("MOCK_STOP_REQUEST");
                        return chain.proceed();
                    });
            hooks.deoptimize(mock);
            hooks.deoptimize(holder);
            // 分组安装，单组异常有准确来源且不跳过后续路线/停止 Hook。
            try {
                installBindings(loader);
            } catch (Throwable error) {
                failure("BINDINGS", error);
            }
            try {
                policy.install(loader);
            } catch (Throwable error) {
                failure("POLICY", error);
            }
            try {
                if (routes == null) routes = new RouteHooks(module, session);
                routes.install(loader);
            } catch (Throwable error) {
                failure("ROUTE", error);
            }
            try {
                installStopBroadcast(loader);
            } catch (Throwable error) {
                failure("STOP_BROADCAST", error);
            }
            hooks.deoptimize(
                    Class.forName("com.lerist.fakelocation.service.RockerService", false, loader));
        } catch (ClassNotFoundException ignored) {
        } catch (Throwable error) {
            failure("INSTALL", error);
        }
    }

    private Object reconnect(Class<?> mock, ClassLoader loader) throws Throwable {
        Object owner = call(method(mock, "ඈ"), null);
        int ordinal = ((Enum<?>) mode.get(owner)).ordinal();
        if (ordinal == 0) {
            Object root = call(rootSingleton, null);
            rootRemote.set(root, null);
            return call(rootGetter, root);
        }
        Class<?> service = Class.forName(HostAbi.PREFIX + "ڛޖڛ", false, loader);
        if (!Boolean.TRUE.equals(call(method(service, "ǆ"), null))) {
            Class<?> app = Class.forName(HostAbi.PREFIX + "ޙൈ", false, loader);
            Context context = (Context) call(method(app, "ඈ"), null);
            call(method(service, "ഈ", Context.class), null, context);
        }
        return call(method(service, "ǋ"), null);
    }

    private void inspectBackend(Object remote) throws Throwable {
        android.os.IBinder binder = ((IInterface) remote).asBinder();
        if (binder == null) return;
        info(
                "MOCK_BACKEND_BOUND class="
                        + remote.getClass().getName()
                        + " alive="
                        + binder.isBinderAlive());
        // 本地 test-provider Binder 没有组件版本协议，避免误报为旧 system_server。
        if (binder.queryLocalInterface(binder.getInterfaceDescriptor()) != null) {
            info("MOCK_BACKEND_LOCAL transport=in-process");
            return;
        }
        // 只对 root 模式应用组件版本门控；独立非 root 服务没有此事务。
        ClassLoader loader = remote.getClass().getClassLoader();
        Class<?> mock = Class.forName(HostAbi.PREFIX + "ŒޘŒ", false, loader);
        Object owner = call(method(mock, "ඈ"), null);
        if (((Enum<?>) mode.get(owner)).ordinal() != 0) return;
        int version = ComponentState.version(binder);
        info("MOCK_BACKEND_RUNTIME version=" + version + " supported=" + (version > 0));
        if (version == ComponentState.ABSENT) throw new android.os.DeadObjectException();
        if (version != ComponentState.VERSION) {
            ComponentState.NotReady error = ComponentState.resident(version);
            info(error.getMessage());
            try {
                Class<?> app = Class.forName(HostAbi.PREFIX + "ޙൈ", false, loader);
                UserNotice.show((Context) call(method(app, "ඈ"), null), error.userMessage);
            } catch (Throwable noticeError) {
                failure("COMPONENT_NOTICE", noticeError);
            }
            throw error;
        }
    }

    private void installTimeGuard(ClassLoader loader) throws Exception {
        Class<?> expiry = Class.forName(HostAbi.PREFIX + "ɕ", false, loader);
        hooks.attach(method(expiry, "ඈ"), chain -> false);
        hooks.deoptimize(expiry);
    }

    private void installBindings(ClassLoader loader) throws Exception {
        Class<?> owner = Class.forName(HostAbi.PREFIX + "ih0", false, loader);
        if (binding == null) binding = new ServiceBindings(module, owner);
        hooks.attach(
                method(owner, "ඓ", Intent.class, long.class),
                chain -> {
                    Intent request = (Intent) chain.getArg(0);
                    if (!hostIntent(request)) return chain.proceed();
                    return binding.connect(
                            chain.getThisObject(), request, ((Number) chain.getArg(1)).longValue());
                });
        hooks.attach(
                method(owner, "ල", Intent.class, long.class),
                chain -> {
                    Intent request = (Intent) chain.getArg(0);
                    if (!hostIntent(request)) return chain.proceed();
                    binding.connectAsync(chain.getThisObject(), request);
                    return null;
                });
        hooks.deoptimize(owner);
        hooks.deoptimize(Class.forName(HostAbi.PREFIX + "ܜޓܜ", false, loader));
        hooks.deoptimize(Class.forName(HostAbi.PREFIX + "ڛޖڛ", false, loader));
    }

    private void installStopBroadcast(ClassLoader loader) throws Exception {
        Class<?> owner = Class.forName(HostAbi.PREFIX + "lv0$ஆ", false, loader);
        hooks.attach(
                method(owner, "onReceive", Context.class, Intent.class),
                chain -> {
                    session.stopRecovery("STOP_FL_MOCK-broadcast");
                    info("MOCK_STOP_BROADCAST");
                    return chain.proceed();
                });
        hooks.deoptimize(owner);
    }

    private static boolean hostIntent(Intent request) {
        return request != null
                && request.getComponent() != null
                && ModuleInfo.TARGET_PACKAGE.equals(request.getComponent().getPackageName());
    }

    private static boolean alive(Object value) {
        return value instanceof IInterface
                && ((IInterface) value).asBinder() != null
                && ((IInterface) value).asBinder().isBinderAlive();
    }

    private void info(String message) {
        module.log(Log.INFO, ModuleInfo.LOG_TAG, message);
    }

    private void failure(String source, Throwable error) {
        module.log(Log.ERROR, ModuleInfo.LOG_TAG, "RUNTIME_HOOK_FAILED " + source, error);
    }
}

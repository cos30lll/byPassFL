package com.fl.bypass.runtime.route;

import static com.fl.bypass.core.Reflector.field;
import static com.fl.bypass.core.Reflector.method;

import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.core.HookRegistry;
import com.fl.bypass.host.HostAbi;
import com.fl.bypass.runtime.session.MockSession;

import io.github.libxposed.api.XposedModule;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

/** Owns route pause, recovery timing, stop, and completion state. */
public final class RouteHooks {
    private final XposedModule module;
    private final HookRegistry hooks;
    private final MockSession session;
    private final Map<Object, Long> waiting = Collections.synchronizedMap(new IdentityHashMap<>());
    private final Set<Object> manualPauses =
            Collections.synchronizedSet(
                    Collections.newSetFromMap(new IdentityHashMap<Object, Boolean>()));

    public RouteHooks(XposedModule module, MockSession session) {
        this.module = module;
        this.hooks = new HookRegistry(module, "route");
        this.session = session;
    }

    public synchronized void install(ClassLoader loader) throws Exception {
        Class<?> service = Class.forName(HostAbi.PREFIX + "ღޏღ", false, loader);
        Class<?> handler = Class.forName(HostAbi.PREFIX + "ღޏღ$ඈ", false, loader);
        Field outer = field(handler, "ඈ"),
                paused = field(service, "ஔ"),
                running = field(service, "ਊ");
        Field completed = field(service, "ൡ"), anchor = field(service, "Ԝ");
        hooks.attach(
                method(service, "start"),
                chain -> {
                    manualPauses.remove(chain.getThisObject());
                    waiting.remove(chain.getThisObject());
                    return chain.proceed();
                });
        hooks.attach(
                method(service, "pause"),
                chain -> {
                    // 先登记再让原方法入队，覆盖 sendMessage 与置 ஔ 字段的线程竞争。
                    manualPauses.add(chain.getThisObject());
                    waiting.remove(chain.getThisObject());
                    session.suspendRecovery();
                    return chain.proceed();
                });
        hooks.attach(
                method(service, "resume"),
                chain -> {
                    manualPauses.remove(chain.getThisObject());
                    waiting.remove(chain.getThisObject());
                    session.resumeRecovery();
                    return chain.proceed();
                });
        hooks.attach(
                method(service, "stop"),
                chain -> {
                    session.stopRecovery("route-stop");
                    manualPauses.remove(chain.getThisObject());
                    waiting.remove(chain.getThisObject());
                    return chain.proceed();
                });
        hooks.attach(
                method(service, "onDestroy"),
                chain -> {
                    session.stopRecovery("route-service-destroy");
                    waiting.remove(chain.getThisObject());
                    manualPauses.remove(chain.getThisObject());
                    return chain.proceed();
                });
        hooks.attach(
                method(handler, "handleMessage", Message.class),
                chain -> {
                    Handler receiver = (Handler) chain.getThisObject();
                    Object route = outer.get(receiver);
                    int what = ((Message) chain.getArg(0)).what;
                    boolean manual = manualPauses.contains(route) || session.suspended();
                    boolean active = running.getBoolean(route) && !completed.getBoolean(route);
                    if (what == 0 && manual) return null;
                    if ((what == 0 || what == 3)
                            && active
                            && !manual
                            && !paused.getBoolean(route)
                            && session.wanted()) {
                        boolean healthy = session.healthyOrRecover();
                        // 恢复调用可能等待 Binder；其间的用户 pause/stop 必须优先。
                        if (manualPauses.contains(route)
                                || session.suspended()
                                || !running.getBoolean(route)
                                || completed.getBoolean(route)) return null;
                        if (!healthy && session.wanted()) {
                            if (!waiting.containsKey(route)) {
                                waiting.put(route, SystemClock.elapsedRealtime());
                                info("ROUTE_RECOVERY_WAIT source=" + what + " manual_pause=false");
                            }
                            receiver.removeMessages(0);
                            receiver.sendEmptyMessageDelayed(0, 1000);
                            return null;
                        }
                        Long first = waiting.remove(route);
                        if (healthy && first != null) {
                            long gap = Math.max(0, SystemClock.elapsedRealtime() - first);
                            anchor.setLong(route, anchor.getLong(route) + gap);
                            info("ROUTE_RECOVERED clock_gap_ms=" + gap);
                        }
                        if (what == 3 && healthy) {
                            receiver.removeMessages(0);
                            receiver.sendEmptyMessageDelayed(0, 1000);
                            info("ROUTE_AUTO_PAUSE_RETRIED manual_pause=false");
                            return null;
                        }
                        if (!healthy && what == 0) {
                            receiver.removeMessages(0);
                            receiver.sendEmptyMessage(3);
                            info("ROUTE_RECOVERY_ABORTED");
                            return null;
                        }
                    }
                    if (what == 1 || what == 2 || what == 5 || what == 3) waiting.remove(route);
                    if (what == 2) {
                        manualPauses.remove(route);
                        session.stopRecovery("route-stop");
                    }
                    if (what == 5) {
                        manualPauses.remove(route);
                        session.stopRecovery("route-finish");
                    }
                    if (what == 3 && manual) session.suspendRecovery();
                    if (what == 2 || what == 3 || what == 5)
                        info(
                                "ROUTE_EVENT what="
                                        + what
                                        + " manual_pause="
                                        + manual
                                        + " backend_wanted="
                                        + session.wanted());
                    return chain.proceed();
                });
        hooks.deoptimize(handler);
        hooks.deoptimize(service);
    }

    private void info(String message) {
        module.log(Log.INFO, ModuleInfo.LOG_TAG, message);
    }
}

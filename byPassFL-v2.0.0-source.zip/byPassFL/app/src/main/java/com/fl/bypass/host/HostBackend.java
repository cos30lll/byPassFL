package com.fl.bypass.host;

import java.lang.reflect.Field;

/** Access to the host's root backend holder; never initializes or deploys payloads. */
public final class HostBackend {
    private HostBackend() {}

    public static Object lookup(ClassLoader loader) throws Exception {
        Class<?> holder = Class.forName(HostAbi.ROOT_BACKEND + "$\u0dc5", true, loader);
        Field field = holder.getDeclaredField("\u0d88");
        field.setAccessible(true);
        return field.get(null);
    }
}

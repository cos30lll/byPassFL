package com.fl.bypass.host;

/** 仅覆盖内置位置子类本次调用的策略检查，finally 恢复线程状态。 */
public final class PolicyScope {
    private PolicyScope() {}

    private static final ThreadLocal<Integer> depth = new ThreadLocal<>();

    public static boolean active() {
        return depth.get() != null;
    }

    public static void enter() {
        Integer previous = depth.get();
        depth.set(previous == null ? 1 : previous + 1);
    }

    public static void exit() {
        Integer current = depth.get();
        if (current == null || current <= 1) depth.remove();
        else depth.set(current - 1);
    }
}

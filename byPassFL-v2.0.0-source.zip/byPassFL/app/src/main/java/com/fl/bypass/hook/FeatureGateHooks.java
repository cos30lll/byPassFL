package com.fl.bypass.hook;

import android.util.Log;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.host.HostAbi;

import io.github.libxposed.api.XposedInterface;
import io.github.libxposed.api.XposedModule;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** 原始 Unicode 名称来自内存 DEX；JADX 的 mXXXX 别名不得用于运行时查找。 */
public final class FeatureGateHooks {
    static final long EXPIRY_MS = 4102444799000L; // 2099-12-31 23:59:59 UTC
    private final XposedModule module;
    private final String processName;
    private final Set<Method> installed = new HashSet<>();
    private final Set<Method> deoptimized = new HashSet<>();
    private final Set<String> deferred = new HashSet<>();
    private final List<String[]> gateCallers = new ArrayList<>();
    private int failed;

    public FeatureGateHooks(XposedModule module, String processName) {
        this.module = module;
        this.processName = processName;
        loadCallerList();
    }

    private void loadCallerList() {
        try (ZipFile apk = new ZipFile(module.getModuleApplicationInfo().sourceDir)) {
            ZipEntry entry = apk.getEntry("assets/pro_gate_callers.tsv");
            if (entry == null) throw new IllegalStateException("caller list missing from APK");
            try (BufferedReader reader =
                    new BufferedReader(new InputStreamReader(apk.getInputStream(entry), "UTF-8"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\t", 2);
                    if (parts.length == 2) gateCallers.add(parts);
                }
            }
        } catch (Throwable error) {
            failure("CALLER_LIST", error);
        }
    }

    public synchronized boolean install(ClassLoader loader, String phase) {
        if (loader == null) return false;
        int before = installed.size();
        Class<?> gate = find(HostAbi.PREFIX + "x92", loader);
        if (gate != null) {
            replace(gate, "\u0d93", boolean.class, true); // ඓ：实际专业版功能门控
            replace(gate, "\u0d87", long.class, EXPIRY_MS); // ඇ：第一期限
            replace(gate, "\u0dc5", long.class, EXPIRY_MS); // ළ：第二期限
            replace(gate, "\u02a5", String.class, "1"); // ʥ：非免费版标记
            replace(gate, "\u01ca", boolean.class, false); // Ǌ：未到期
            replace(gate, "\u02a4", boolean.class, false); // ʤ：未到期
            replace(gate, "\u0dbd", boolean.class, false); // ල：不是免费标记 0
        }
        Class<?> bridge = find(HostAbi.PREFIX + "mq0", loader);
        if (bridge != null) {
            replace(bridge, "\u0dc5", int.class, 0);
            replaceKeys(bridge, "\u0d88", String.class, String.class);
        }
        Class<?> swipe = find("androidx.swiperefreshlayout.widget.SwipeUtils", loader);
        if (swipe != null) {
            replace(swipe, "isQualified", int.class, 0);
            replace(swipe, "sq", int.class, 0);
            replaceKeys(swipe, "getKeys", String.class, String.class);
            replaceKeys(swipe, "gk", byte[].class, String.class);
        }
        Class<?> user = find(HostAbi.PREFIX + "y92", loader);
        if (user != null) {
            replace(user, "getType", int.class, 1);
            replace(user, "getProindate", long.class, EXPIRY_MS);
            if ("after-application-onCreate".equals(phase)
                    || "current-application".equals(phase)
                    || "first-activity-resume".equals(phase)) {
                installUserHooks(user, loader);
            }
        }

        // m8568 原始方法始终返回 false；只移除 stopSelf 副作用，保持返回约定。
        Class<?> mockService = find(HostAbi.PREFIX + "\u069b\u0796\u069b", loader);
        if (mockService != null) {
            replace(mockService, "\u01ca", boolean.class, false);
            deoptClass(mockService);
        }
        // 路线服务 onCreate 与 Handler 的持续门控必须去优化，避免旧内联结果。
        for (String name :
                new String[] {
                    HostAbi.PREFIX + "\u10e6\u078f\u10e6",
                    HostAbi.PREFIX + "\u10e6\u078f\u10e6$\u0d88",
                    HostAbi.PREFIX + "\u071c\u0793\u071c"
                }) {
            Class<?> service = find(name, loader);
            if (service != null) deoptClass(service);
        }
        if (gate != null) deoptGateCallers(loader);
        if (before != installed.size() || "before-application-onCreate".equals(phase)) {
            info(
                    "INSTALL_SUMMARY phase="
                            + phase
                            + " hooks="
                            + installed.size()
                            + " deopt="
                            + deoptimized.size()
                            + " failed="
                            + failed
                            + " process="
                            + processName);
        }
        return gate != null;
    }

    private void installUserHooks(Class<?> user, ClassLoader loader) {
        replace(user, "getType", int.class, 1);
        replace(user, "getProindate", long.class, EXPIRY_MS);
        Class<?> prefs = find(HostAbi.PREFIX + "\u010f\u0592\u010f$\u0dbd", loader);
        if (prefs == null) return;
        try {
            final Field type = user.getDeclaredField("type");
            final Field expiry = user.getDeclaredField("proindate");
            type.setAccessible(true);
            expiry.setAccessible(true);
            Method reader = prefs.getDeclaredMethod("\u0d96"); // ඖ() -> y92
            if (reader.getReturnType() != user)
                throw new NoSuchMethodException("user reader ABI mismatch");
            attach(
                    reader,
                    chain -> {
                        Object value = chain.proceed();
                        // 保留空账号和原 token/key；只修改本次读取对象，避免持久化污染。
                        if (value != null) {
                            type.setInt(value, 1);
                            expiry.setLong(value, EXPIRY_MS);
                        }
                        return value;
                    });
            deoptClass(prefs);
        } catch (Throwable error) {
            failure("USER_STATE", error);
        }
    }

    private void replace(
            Class<?> owner, String name, Class<?> resultType, Object value, Class<?>... params) {
        try {
            Method method = owner.getDeclaredMethod(name, params);
            if (method.getReturnType() != resultType) {
                throw new NoSuchMethodException("return type mismatch: " + method);
            }
            attach(method, chain -> value);
        } catch (Throwable error) {
            failure(owner.getName() + "." + name, error);
        }
    }

    private void replaceKeys(Class<?> owner, String name, Class<?>... params) {
        try {
            Method method = owner.getDeclaredMethod(name, params);
            if (method.getReturnType() != Object[].class) {
                throw new NoSuchMethodException("keys ABI mismatch: " + method);
            }
            attach(
                    method,
                    chain ->
                            new Object[] {
                                "1", String.valueOf(EXPIRY_MS), String.valueOf(EXPIRY_MS)
                            });
        } catch (Throwable error) {
            failure(owner.getName() + "." + name, error);
        }
    }

    private void attach(Method method, XposedInterface.Hooker hooker) {
        if (installed.contains(method)) return;
        if (Modifier.isAbstract(method.getModifiers())) {
            throw new IllegalArgumentException("abstract hook target: " + method);
        }
        method.setAccessible(true);
        final AtomicBoolean firstHit = new AtomicBoolean();
        module.hook(method)
                .intercept(
                        chain -> {
                            if (firstHit.compareAndSet(false, true)) {
                                info(
                                        "HOOK_HIT "
                                                + method.getDeclaringClass().getName()
                                                + "."
                                                + method.getName());
                            }
                            return hooker.intercept(chain);
                        });
        installed.add(method);
        info("HOOK_INSTALLED " + method.getDeclaringClass().getName() + "." + method.getName());
    }

    private Class<?> find(String name, ClassLoader loader) {
        try {
            return Class.forName(name, false, loader);
        } catch (ClassNotFoundException unavailable) {
            if (deferred.add(name)) info("CLASS_DEFERRED " + name);
        } catch (Throwable error) {
            failure("CLASS " + name, error);
        }
        return null;
    }

    private void deoptGateCallers(ClassLoader loader) {
        for (String[] target : gateCallers) {
            Class<?> owner = find(target[0], loader);
            if (owner == null) continue;
            try {
                for (Method method : owner.getDeclaredMethods()) {
                    if (!target[1].equals(method.getName())) continue;
                    int flags = method.getModifiers();
                    if (Modifier.isAbstract(flags)
                            || Modifier.isNative(flags)
                            || !deoptimized.add(method)) continue;
                    if (!module.deoptimize(method)) {
                        info("DEOPT_UNAVAILABLE " + owner.getName() + "." + method.getName());
                    }
                }
            } catch (Throwable error) {
                failure("DEOPT_CALLER " + target[0] + "." + target[1], error);
            }
        }
    }

    private void deoptClass(Class<?> owner) {
        try {
            for (Method method : owner.getDeclaredMethods()) {
                int flags = method.getModifiers();
                if (Modifier.isAbstract(flags)
                        || Modifier.isNative(flags)
                        || !deoptimized.add(method)) continue;
                module.deoptimize(method);
            }
        } catch (Throwable error) {
            failure("DEOPT " + owner.getName(), error);
        }
    }

    private void info(String message) {
        module.log(Log.INFO, ModuleInfo.LOG_TAG, message);
    }

    private void failure(String target, Throwable error) {
        failed++;
        module.log(Log.ERROR, ModuleInfo.LOG_TAG, "HOOK_FAILED " + target, error);
    }
}

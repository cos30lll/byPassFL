package com.fl.bypass.runtime.service;

import static com.fl.bypass.core.Reflector.field;
import static com.fl.bypass.core.Reflector.method;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import com.fl.bypass.ModuleInfo;

import io.github.libxposed.api.XposedModule;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.IdentityHashMap;
import java.util.Map;

/** ih0 的共用连接修复。ABI 证据：docs/abi/runtime-abi.tsv；只接受宿主自己的 Service Intent。 */
public final class ServiceBindings {
    private final XposedModule module;
    private final Map<Object, Binding> bindings = new IdentityHashMap<>();
    private final Field app, remote, connection, connected, connecting, complete, intentField;
    private final Method convert, notifyConnected, notifyDisconnected, notifyDied;

    public ServiceBindings(XposedModule module, Class<?> owner) throws Exception {
        this.module = module;
        app = field(owner, "ඈ");
        remote = field(owner, "ʤ");
        connection = field(owner, "ஆ");
        connected = field(owner, "ඇ");
        connecting = field(owner, "ළ");
        complete = field(owner, "ʥ");
        intentField = field(owner, "Ǌ");
        convert = method(owner, "ʥ", ComponentName.class, IBinder.class);
        notifyConnected = method(owner, "ഏ", ComponentName.class, IBinder.class);
        notifyDisconnected = method(owner, "ǋ", ComponentName.class);
        notifyDied = method(owner, "ஹ", ComponentName.class);
    }

    public boolean connect(Object invoker, Intent request, long waitMs) throws Exception {
        if (request == null
                || request.getComponent() == null
                || !ModuleInfo.TARGET_PACKAGE.equals(request.getComponent().getPackageName()))
            return false;
        Binding state;
        synchronized (bindings) {
            state = bindings.get(invoker);
            if (state == null) {
                state = new Binding(invoker, (Context) app.get(invoker));
                bindings.put(invoker, state);
            }
        }
        state.begin(request);
        if (Looper.myLooper() == Looper.getMainLooper() || waitMs <= 0) return state.isConnected();
        long deadline = SystemClock.elapsedRealtime() + Math.min(Math.max(waitMs, 100), 3000);
        synchronized (state) {
            while (!state.isConnected()
                    && state.pending
                    && SystemClock.elapsedRealtime() < deadline) {
                try {
                    state.wait(Math.min(50, Math.max(1, deadline - SystemClock.elapsedRealtime())));
                } catch (InterruptedException error) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            return state.isConnected();
        }
    }

    public void connectAsync(Object invoker, Intent intent) throws Exception {
        connect(invoker, intent, 0);
    }

    private final class Binding {
        final Object invoker;
        final Context context;
        IBinder binder;
        ServiceConnection current;
        boolean pending;
        long since;
        long retryAfter;

        Binding(Object invoker, Context context) {
            this.invoker = invoker;
            this.context = context;
        }

        synchronized boolean isConnected() throws Exception {
            boolean value =
                    connected.getBoolean(invoker)
                            && complete.getBoolean(invoker)
                            && remote.get(invoker) != null
                            && (binder == null || binder.isBinderAlive());
            if (!value && binder != null && !binder.isBinderAlive()) clear();
            return value;
        }

        synchronized void begin(Intent request) throws Exception {
            if (isConnected()) return;
            long now = SystemClock.elapsedRealtime();
            if (now < retryAfter || (pending && now - since < 3000)) return;
            release();
            pending = true;
            since = now;
            connecting.setBoolean(invoker, true);
            connected.setBoolean(invoker, false);
            complete.setBoolean(invoker, false);
            intentField.set(invoker, new Intent(request));
            ServiceConnection next =
                    new ServiceConnection() {
                        @Override
                        public void onServiceConnected(ComponentName name, IBinder value) {
                            try {
                                Object target = convert.invoke(invoker, name, value);
                                synchronized (Binding.this) {
                                    if (current != this) return;
                                    if (target == null || value == null || !value.isBinderAlive()) {
                                        failed(this, "null-binding");
                                        return;
                                    }
                                    binder = value;
                                    remote.set(invoker, target);
                                    connected.setBoolean(invoker, true);
                                    connecting.setBoolean(invoker, false);
                                    pending = true;
                                    retryAfter = 0;
                                }
                                try {
                                    notifyConnected.invoke(invoker, name, value);
                                } finally {
                                    synchronized (Binding.this) {
                                        if (current == this) {
                                            complete.setBoolean(invoker, true);
                                            pending = false;
                                        }
                                        Binding.this.notifyAll();
                                    }
                                }
                                info("SERVICE_CONNECTED component=" + name.getClassName());
                            } catch (Throwable error) {
                                failed(this, "callback-" + error.getClass().getSimpleName());
                            }
                        }

                        @Override
                        public void onServiceDisconnected(ComponentName name) {
                            disconnected(this, name, false);
                        }

                        @Override
                        public void onBindingDied(ComponentName name) {
                            disconnected(this, name, true);
                        }

                        @Override
                        public void onNullBinding(ComponentName name) {
                            failed(this, "null-binding");
                        }
                    };
            current = next;
            connection.set(invoker, next);
            try {
                if (!context.bindService(request, next, Context.BIND_AUTO_CREATE))
                    failed(next, "bind-false");
            } catch (SecurityException error) {
                failed(next, "permission-denied");
                throw error;
            } catch (RuntimeException error) {
                failed(next, error.getClass().getSimpleName());
                throw error;
            }
        }

        void disconnected(ServiceConnection source, ComponentName name, boolean died) {
            try {
                synchronized (this) {
                    if (current != source) return;
                    clear();
                    // 保留登记直到下一次 begin 解绑，避免原实现丢掉连接对象而泄漏绑定。
                    retryAfter = SystemClock.elapsedRealtime() + 300;
                    notifyAll();
                }
                (died ? notifyDied : notifyDisconnected).invoke(invoker, name);
                info("SERVICE_DISCONNECTED component=" + name.getClassName() + " died=" + died);
            } catch (Throwable error) {
                failure(error);
            }
        }

        synchronized void failed(ServiceConnection source, String reason) {
            if (current != source) return;
            try {
                clear();
                retryAfter = SystemClock.elapsedRealtime() + 1000;
                release();
                notifyAll();
                info("SERVICE_BIND_FAILED reason=" + reason);
            } catch (Throwable error) {
                failure(error);
            }
        }

        private void clear() throws Exception {
            binder = null;
            pending = false;
            remote.set(invoker, null);
            connected.setBoolean(invoker, false);
            connecting.setBoolean(invoker, false);
            complete.setBoolean(invoker, false);
        }

        private void release() throws Exception {
            ServiceConnection previous = current;
            current = null;
            if (previous != null) {
                try {
                    context.unbindService(previous);
                } catch (IllegalArgumentException ignored) {
                }
            }
            connection.set(invoker, null);
        }
    }

    private void info(String message) {
        module.log(Log.INFO, ModuleInfo.LOG_TAG, message);
    }

    private void failure(Throwable error) {
        module.log(Log.ERROR, ModuleInfo.LOG_TAG, "SERVICE_BIND_CALLBACK_FAILED", error);
    }
}

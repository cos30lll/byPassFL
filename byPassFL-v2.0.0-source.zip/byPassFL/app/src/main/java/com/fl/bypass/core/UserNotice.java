package com.fl.bypass.core;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.widget.Toast;

/** Rate-limited main-thread messages for host actions. */
public final class UserNotice {
    private static long lastNotice;

    private UserNotice() {}

    public static synchronized void show(Context context, String message) {
        if (context == null) return;
        long now = SystemClock.elapsedRealtime();
        if (lastNotice != 0 && now - lastNotice < 4000) return;
        lastNotice = now;
        new Handler(Looper.getMainLooper())
                .post(() -> Toast.makeText(context, message, Toast.LENGTH_LONG).show());
    }
}

package com.fl.bypass.backend;

import android.content.Context;
import android.os.SystemClock;
import android.util.Log;

import dalvik.system.InMemoryDexClassLoader;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.host.HostAbi;
import com.fl.bypass.host.HostBackend;

import io.github.libxposed.api.XposedModule;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

/** 后端代码和缓存由当前模块提供；后端缓存不包含账号、token 或授权 key。 */
public final class BackendBootstrap {
    private final XposedModule module;
    private BackendAssets assets;
    private Context context;
    private PayloadHooks payloadHooks;
    private boolean loading;
    private volatile boolean loaded;
    private volatile long retryAfter;
    private final AtomicBoolean queued = new AtomicBoolean();

    public BackendBootstrap(XposedModule module) {
        this.module = module;
    }

    public void request(Context supplied) {
        if (supplied == null
                || loaded
                || SystemClock.elapsedRealtime() < retryAfter
                || !queued.compareAndSet(false, true)) return;
        Context app =
                supplied.getApplicationContext() != null
                        ? supplied.getApplicationContext()
                        : supplied;
        try {
            Thread worker =
                    new Thread(
                            () -> {
                                try {
                                    ensure(app);
                                } finally {
                                    queued.set(false);
                                }
                            },
                            "ByPassFL-Bootstrap");
            worker.setDaemon(true);
            worker.start();
        } catch (Throwable error) {
            queued.set(false);
            module.log(Log.ERROR, ModuleInfo.LOG_TAG, "BACKEND_WORKER_FAILED", error);
        }
    }

    @SuppressWarnings("deprecation") // Fixed host ABI uses PackageInfo.versionCode on Android 8.
    private synchronized boolean ensure(Context supplied) {
        if (supplied == null) return false;
        context =
                supplied.getApplicationContext() != null
                        ? supplied.getApplicationContext()
                        : supplied;
        if (assets == null) assets = new BackendAssets(module, context);
        if (loaded) return true;
        if (loading || SystemClock.elapsedRealtime() < retryAfter) return false;
        loading = true;
        try {
            if (!ModuleInfo.TARGET_PACKAGE.equals(context.getPackageName())
                    || context.getPackageManager()
                                    .getPackageInfo(ModuleInfo.TARGET_PACKAGE, 0)
                                    .versionCode
                            != ModuleInfo.TARGET_VERSION_CODE) {
                throw new IllegalStateException("backend target must be 1.5.2/1702");
            }
            ClassLoader parent = context.getClassLoader();
            Object nativeContext =
                    Class.forName(HostAbi.PREFIX + "\u0799\u0d48", true, parent)
                            .getDeclaredMethod("\u0d88")
                            .invoke(null);
            if (nativeContext == null) {
                info("BACKEND_DEFERRED host-context");
                return false;
            }
            byte[] dex = assets.cachedAsset("jed1.dex");
            ClassLoader payloadLoader = new InMemoryDexClassLoader(ByteBuffer.wrap(dex), parent);
            assets.fillCaches();
            if (payloadHooks == null) payloadHooks = new PayloadHooks(module, context, assets);
            payloadHooks.install(payloadLoader);
            Class<?> entry = Class.forName(HostAbi.PAYLOAD_ENTRY, true, payloadLoader);
            entry.getDeclaredMethod("\u08a1\u08a1").invoke(null);
            Object backend = HostBackend.lookup(parent);
            if (backend == null
                    || !backend.getClass().getName().equals(HostAbi.PAYLOAD_PREFIX + "\u0d61")) {
                throw new IllegalStateException("native entry did not install root backend");
            }
            loaded = true;
            info("BACKEND_LOADED class=" + backend.getClass().getName() + " source=bundled");
            try {
                assets.fillCaches();
            } catch (Throwable e) {
                module.log(
                        Log.WARN,
                        ModuleInfo.LOG_TAG,
                        "CACHE_FILL_FAILED backend remains loaded",
                        e);
            }
            return true;
        } catch (Throwable error) {
            retryAfter = SystemClock.elapsedRealtime() + 2000;
            module.log(Log.ERROR, ModuleInfo.LOG_TAG, "BACKEND_LOAD_FAILED", error);
            return false;
        } finally {
            loading = false;
        }
    }

    public synchronized void prepareComponentForStart(Context supplied) {
        // 启动工作线程等待这次初始化实际完成，避免后台 request 与 native 启动竞争。
        if (!ensure(supplied))
            throw new ComponentState.NotReady(
                    "BACKEND_NOT_LOADED", "定位后端尚未准备完成，请稍后重试并保留 ByPassFL 日志。");
        try {
            assets.fillCaches();
            int version = ComponentState.lookup(context.getClassLoader()).version();
            if (version == ComponentState.ABSENT)
                info("BACKEND_COMPONENT_RUNTIME absent awaiting-native-init");
            else
                info(
                        version == ComponentState.VERSION
                                ? "BACKEND_COMPONENT_RUNTIME version=" + version
                                : "BACKEND_COMPONENT_LEGACY version="
                                        + version
                                        + " staged_version="
                                        + ComponentState.VERSION
                                        + " resident_replaced=false");
        } catch (Exception error) {
            module.log(Log.ERROR, ModuleInfo.LOG_TAG, "BACKEND_COMPONENT_PREPARE_FAILED", error);
            throw new ComponentState.NotReady(
                    "BACKEND_COMPONENT_PREPARE_FAILED", "定位组件准备失败，请保留 ByPassFL 日志后重试。");
        }
    }

    private void info(String value) {
        module.log(Log.INFO, ModuleInfo.LOG_TAG, value);
    }
}

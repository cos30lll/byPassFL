package com.fl.bypass.backend;

import android.content.Context;
import android.location.Location;
import android.os.SystemClock;
import android.util.Log;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.host.HostAbi;
import com.fl.bypass.host.PolicyScope;

import io.github.libxposed.api.XposedModule;

import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/** Installs hooks against the bundled payload ABI after its class loader is available. */
final class PayloadHooks {
    private final XposedModule module;
    private final Context context;
    private final BackendAssets assets;
    private final Set<Method> installed = new HashSet<>();

    PayloadHooks(XposedModule module, Context context, BackendAssets assets) {
        this.module = module;
        this.context = context;
        this.assets = assets;
    }

    void install(ClassLoader loader) throws Exception {
        installComponentHooks(loader);
        installNativeDiagnostics(loader);
        // 三个线程只负责远程停机或反篡改退出，不承担 root 初始化。
        for (String leaf : new String[] {"\u01c6", "\u0478", "\u0857"}) {
            Class<?> owner = Class.forName(HostAbi.PAYLOAD_PREFIX + leaf, false, loader);
            noOp(owner.getDeclaredMethod("run"));
        }
        Class<?> downloader = Class.forName(HostAbi.PAYLOAD_PREFIX + "\u0d8c", false, loader);
        Method export = downloader.getDeclaredMethod("\u08a1", int.class, String.class);
        module.hook(export)
                .setExceptionMode(io.github.libxposed.api.XposedInterface.ExceptionMode.PASSTHROUGH)
                .intercept(
                        chain -> {
                            File destination = assets.hostFile((String) chain.getArg(1));
                            byte[] apk = assets.cachedAsset("jed2.apk");
                            BackendAssets.atomicWrite(destination, apk, false);
                            info("BACKEND_COMPONENT_READY bytes=" + apk.length);
                            return destination.length() == apk.length;
                        });
        installed.add(export);
        // 原 APK 的 native 资源也随模块携带，缺失资源时使用相同字节的内置副本。
        Class<?> copier = Class.forName(HostAbi.PAYLOAD_PREFIX + "\u0d0f", false, loader);
        Method copy = copier.getDeclaredMethod("\u08a1", Context.class, String.class, String.class);
        module.hook(copy)
                .setExceptionMode(io.github.libxposed.api.XposedInterface.ExceptionMode.PASSTHROUGH)
                .intercept(
                        chain -> {
                            String relative = "native/" + (String) chain.getArg(1);
                            if (!assets.assets().has(relative)) return chain.proceed();
                            File destination = assets.hostFile((String) chain.getArg(2));
                            BackendAssets.atomicWrite(
                                    destination,
                                    assets.asset(relative),
                                    relative.contains("/inj") || relative.contains("/busybox"));
                            return true;
                        });
        installed.add(copy);
        // DEX ABI：ࢡࢡ.ඥ.ඓ(Location)，不是 JADX 的 C0076/m121 别名。
        Class<?> provider = Class.forName(HostAbi.PAYLOAD_PREFIX + "ඥ", false, loader);
        Method update = provider.getDeclaredMethod("ඓ", Location.class);
        if (update.getReturnType() != void.class)
            throw new NoSuchMethodException("payload location ABI");
        final AtomicBoolean firstLocation = new AtomicBoolean();
        module.hook(update)
                .intercept(
                        chain -> {
                            if (firstLocation.compareAndSet(false, true))
                                info("MOCK_PAYLOAD_LOCATION_ENTRY class=" + provider.getName());
                            PolicyScope.enter();
                            try {
                                return chain.proceed();
                            } finally {
                                PolicyScope.exit();
                            }
                        });
        installed.add(update);
        for (Method target : provider.getDeclaredMethods()) {
            if (!Modifier.isAbstract(target.getModifiers())
                    && !Modifier.isNative(target.getModifiers())) module.deoptimize(target);
        }
        info("MOCK_PAYLOAD_SCOPE_INSTALLED class=" + provider.getName() + " method=ඓ");
        info("BACKEND_HOOKS_READY count=" + installed.size());
    }

    private void installComponentHooks(ClassLoader loader) throws Exception {
        Class<?> root = Class.forName(HostAbi.PAYLOAD_PREFIX + "ൡ", false, loader);
        Method ready = root.getDeclaredMethod("ණ");
        module.hook(ready)
                .intercept(
                        chain -> {
                            // 普通轮询只报告版本是否就绪；不向界面刷新抛出升级异常。
                            try {
                                return runtimeComponentVersion() == ComponentState.VERSION;
                            } catch (Exception error) {
                                return false;
                            }
                        });
        installed.add(ready);
        module.deoptimize(ready);
        Method init = root.getDeclaredMethod("ඌ", Context.class, boolean.class);
        module.hook(init)
                .setExceptionMode(io.github.libxposed.api.XposedInterface.ExceptionMode.PASSTHROUGH)
                .intercept(
                        chain -> {
                            Object result = chain.proceed();
                            // 原初始化会清理旧导出文件；清理结束后必须重新准备组件。
                            assets.fillCaches();
                            info("BACKEND_COMPONENT_AFTER_INIT version=" + ComponentState.VERSION);
                            return result;
                        });
        installed.add(init);
        module.deoptimize(init);
        Method start = root.getDeclaredMethod("Ǌ", Context.class);
        module.hook(start)
                .setExceptionMode(io.github.libxposed.api.XposedInterface.ExceptionMode.PASSTHROUGH)
                .intercept(
                        chain -> {
                            assets.fillCaches();
                            int before = runtimeComponentVersion();
                            if (before >= 0 && before != ComponentState.VERSION)
                                throw ComponentState.resident(before);
                            // 原 ready 同时含缓存布尔值、库名搜索和桥接状态，不能作为驻留证据。
                            Object result = chain.proceed();
                            if (!Integer.valueOf(0).equals(result)) {
                                info(
                                        "BACKEND_COMPONENT_INIT_RESULT rc="
                                                + result
                                                + " version=unchecked");
                                return result;
                            }
                            ComponentState.Connection connected = awaitComponent(5000);
                            int after = connected.version();
                            info(
                                    "BACKEND_COMPONENT_INIT_RESULT rc="
                                            + result
                                            + " version="
                                            + after
                                            + " transport="
                                            + connected.source);
                            if (after >= 0 && after != ComponentState.VERSION)
                                throw ComponentState.resident(after);
                            if (after == ComponentState.ABSENT) {
                                captureNativeFailure(loader);
                                throw new ComponentState.NotReady(
                                        "BACKEND_COMPONENT_SERVICE_MISSING init_rc=0"
                                                + " waited_ms=5000",
                                        "定位组件装载已返回，但服务连接失败。已保存装载日志，请反馈 ByPassFL 日志。");
                            }
                            return result;
                        });
        installed.add(start);
        module.deoptimize(start);
        // 宿主 static 包装器可内联虚调用，须使原始调用点重新走就绪检查。
        Class<?> host = Class.forName(HostAbi.ROOT_BACKEND, false, context.getClassLoader());
        module.deoptimize(host.getDeclaredMethod("ഈ"));
        module.deoptimize(host.getDeclaredMethod("ඓ", Context.class));
        info("BACKEND_COMPONENT_GUARD_INSTALLED expected=" + ComponentState.VERSION);
    }

    private int runtimeComponentVersion() throws Exception {
        return ComponentState.lookup(context.getClassLoader()).version();
    }

    private ComponentState.Connection awaitComponent(long timeoutMs) throws Exception {
        long end = SystemClock.elapsedRealtime() + timeoutMs;
        ComponentState.Connection found = ComponentState.lookup(context.getClassLoader());
        if (found.binder == null) info("BACKEND_COMPONENT_REGISTER_WAIT timeout_ms=" + timeoutMs);
        while (found.binder == null
                && SystemClock.elapsedRealtime() < end
                && android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
            Thread.sleep(Math.min(100, Math.max(1, end - SystemClock.elapsedRealtime())));
            found = ComponentState.lookup(context.getClassLoader());
        }
        return found;
    }

    private void installNativeDiagnostics(ClassLoader loader) throws Exception {
        Class<?> owner = Class.forName(HostAbi.PAYLOAD_PREFIX + "ഏ", false, loader);
        Method inject =
                owner.getDeclaredMethod(
                        "ࢡ",
                        int.class,
                        String.class,
                        String.class,
                        String.class,
                        boolean.class,
                        boolean.class);
        Class<?> resultType = Class.forName(HostAbi.PAYLOAD_PREFIX + "ඖ$ࢡ", false, loader);
        final Field exit = resultType.getDeclaredField("ࢡ"),
                stdout = resultType.getDeclaredField("ࢡࢡ"),
                stderr = resultType.getDeclaredField("ࢡࢡࢡ");
        exit.setAccessible(true);
        stdout.setAccessible(true);
        stderr.setAccessible(true);
        module.hook(inject)
                .setExceptionMode(io.github.libxposed.api.XposedInterface.ExceptionMode.PASSTHROUGH)
                .intercept(
                        chain -> {
                            if (!"system_server".equals(chain.getArg(1))) return chain.proceed();
                            String abi = (String) chain.getArg(3);
                            File boundLoader = prepareNativeLoader(abi);
                            Object[] args = chain.getArgs().toArray();
                            args[2] = boundLoader.getAbsolutePath();
                            info(
                                    "NATIVE_COMPONENT_LOAD_BEGIN abi="
                                            + abi
                                            + " loader="
                                            + boundLoader.getName());
                            Object result = chain.proceed(args);
                            try {
                                info(
                                        result == null
                                                ? "NATIVE_COMPONENT_LOAD_RESULT null"
                                                : "NATIVE_COMPONENT_LOAD_RESULT rc="
                                                        + exit.getInt(result)
                                                        + " stdout="
                                                        + diagnostic(stdout.get(result))
                                                        + " stderr="
                                                        + diagnostic(stderr.get(result)));
                            } catch (Exception error) {
                                module.log(
                                        Log.WARN,
                                        ModuleInfo.LOG_TAG,
                                        "NATIVE_RESULT_LOG_FAILED",
                                        error);
                            }
                            return result;
                        });
        installed.add(inject);
        module.deoptimize(inject);
        // 原 isLoadedLib 使用命令输出中出现文件名作为 true 的依据，记录其结果而不将其视为注册成功。
        Method mapped =
                Class.forName(HostAbi.PAYLOAD_PREFIX + "ൡ", false, loader)
                        .getDeclaredMethod("isLoadedLib", String.class, String.class);
        module.hook(mapped)
                .intercept(
                        chain -> {
                            Object result = chain.proceed();
                            if ("system_server".equals(chain.getArg(0)))
                                info("NATIVE_COMPONENT_MAPPING_HINT value=" + result);
                            return result;
                        });
        installed.add(mapped);
        module.deoptimize(mapped);
        info("NATIVE_COMPONENT_DIAGNOSTICS_INSTALLED");
    }

    private File prepareNativeLoader(String abi) throws Exception {
        String name;
        if ("arm64-v8a".equals(abi)) name = "libfl_init64.so";
        else if ("armeabi-v7a".equals(abi) || "armeabi".equals(abi)) name = "libfl_init.so";
        else if ("x86_64".equals(abi)) name = "libfl_initx64.so";
        else if ("x86".equals(abi)) name = "libfl_initx.so";
        else throw new IllegalArgumentException("unsupported component loader ABI: " + abi);
        byte[] data = assets.asset("native/" + name);
        JSONObject binding = assets.manifest().getJSONObject("native_binding");
        if (!binding.getString("component_sha256")
                .equals(assets.assets().getJSONObject("jed2.apk").getString("sha256"))) {
            throw new IllegalStateException("native/component manifest mismatch");
        }
        String digest = BackendAssets.hex(MessageDigest.getInstance("SHA-256").digest(data));
        // 原注入器会把 basename 复制到 /dev；独立名称与内置 SONAME 一起隔离旧加载句柄。
        File destination =
                assets.hostFile(
                        new File(
                                        context.getFilesDir(),
                                        ModuleInfo.BACKEND_STORAGE_DIR
                                                + "/native/bpf-init-"
                                                + digest.substring(0, 16)
                                                + ".so")
                                .getPath());
        BackendAssets.atomicWrite(destination, data, false);
        info(
                "NATIVE_COMPONENT_BOUND fragment="
                        + binding.getString("digest_fragment")
                        + " loader="
                        + destination.getName());
        return destination;
    }

    private void captureNativeFailure(ClassLoader loader) {
        try {
            // 仅在用户启动且装载返回 0 后连接仍失败时，保存当前相关日志；不启动任何后台抓取器。
            Class<?> shell = Class.forName(HostAbi.PAYLOAD_PREFIX + "ඖ", false, loader);
            Object result =
                    shell.getDeclaredMethod("ࢡ", String[].class, boolean.class, boolean.class)
                            .invoke(
                                    null,
                                    new Object[] {
                                        new String[] {
                                            "logcat -d -v brief -s LINJECT.native:V"
                                                + " libfakeloc_init.so:V InjectDex:V"
                                                + " ByPassFLBackend:V AndroidRuntime:E | tail -c"
                                                + " 12000"
                                        },
                                        true,
                                        true
                                    });
            if (result != null) {
                Field stdout = result.getClass().getDeclaredField("ࢡࢡ");
                stdout.setAccessible(true);
                String text = String.valueOf(stdout.get(result));
                if (text.length() > 8000) text = text.substring(text.length() - 8000);
                info("NATIVE_COMPONENT_FAILURE_LOG " + text);
            }
        } catch (Throwable error) {
            module.log(Log.WARN, ModuleInfo.LOG_TAG, "NATIVE_FAILURE_LOG_UNAVAILABLE", error);
        }
    }

    private static String diagnostic(Object value) {
        String text = String.valueOf(value).replace('\n', ' ').replace('\r', ' ');
        return text.length() > 1200 ? text.substring(0, 1200) : text;
    }

    private void noOp(Method method) {
        if (installed.contains(method)) return;
        module.hook(method).intercept(chain -> null);
        installed.add(method);
    }

    private void info(String value) {
        module.log(Log.INFO, ModuleInfo.LOG_TAG, value);
    }
}

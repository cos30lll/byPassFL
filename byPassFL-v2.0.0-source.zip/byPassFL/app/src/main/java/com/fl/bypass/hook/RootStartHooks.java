package com.fl.bypass.hook;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.backend.BackendBootstrap;
import com.fl.bypass.backend.ComponentState;
import com.fl.bypass.core.UserNotice;
import com.fl.bypass.host.HostAbi;
import com.fl.bypass.host.HostBackend;

import io.github.libxposed.api.XposedModule;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Set;

/** 在原启动线程内限制补丁等待；连接、注入和运行结果仍由宿主原方法决定。 */
public final class RootStartHooks {
    private final XposedModule module;
    private final BackendBootstrap bootstrap;
    private final Set<Method> installed = new HashSet<>();
    private final ThreadLocal<StartState> starting = new ThreadLocal<>();
    private volatile Context context;
    private final Set<Method> deoptimized = new HashSet<>();

    public RootStartHooks(XposedModule module) {
        this.module = module;
        bootstrap = new BackendBootstrap(module);
    }

    public void onApplication(Context app) {
        context = app.getApplicationContext() != null ? app.getApplicationContext() : app;
        bootstrap.request(context);
    }

    public synchronized void install(ClassLoader loader) {
        if (loader == null) return;
        try {
            Class<?> detection = Class.forName(HostAbi.PREFIX + "jm2", false, loader);
            Method getter = detection.getDeclaredMethod("\u0dc5");
            if (installed.add(getter)) module.hook(getter).intercept(chain -> false);
            Method scan = detection.getDeclaredMethod("\u0d88", Throwable.class);
            if (installed.add(scan)) module.hook(scan).intercept(chain -> null);
            Method setter = detection.getDeclaredMethod("\u0d87", boolean.class);
            if (installed.add(setter))
                module.hook(setter)
                        .intercept(
                                chain -> {
                                    detection.getDeclaredField("\u0d88").setBoolean(null, false);
                                    return null;
                                });
            detection.getDeclaredField("\u0d88").setBoolean(null, false);
            for (String name : new String[] {"jm2", "\u0152\u0798\u0152"}) {
                for (Method method :
                        Class.forName(HostAbi.PREFIX + name, false, loader).getDeclaredMethods()) {
                    int flags = method.getModifiers();
                    if (!Modifier.isAbstract(flags)
                            && !Modifier.isNative(flags)
                            && deoptimized.add(method)) module.deoptimize(method);
                }
            }
        } catch (ClassNotFoundException ignored) {
        } catch (Throwable error) {
            failure("DETECTION", error);
        }
        try {
            Class<?> rq = Class.forName(HostAbi.PREFIX + "rq0", false, loader);
            Method load = rq.getDeclaredMethod("\u0dc5", Context.class, String.class);
            if (installed.add(load))
                module.hook(load)
                        .intercept(
                                chain -> {
                                    Context supplied = (Context) chain.getArg(0);
                                    if (supplied != null) {
                                        context =
                                                supplied.getApplicationContext() != null
                                                        ? supplied.getApplicationContext()
                                                        : supplied;
                                        bootstrap.request(context);
                                    }
                                    return null;
                                });
            // 阻止已有异步任务覆盖同一 root 单例，统一在本模块已验哈希的副本上初始化。
            Method async =
                    rq.getDeclaredMethod("\u0b86", Context.class, String.class, String.class);
            async.setAccessible(true);
            if (installed.add(async))
                module.hook(async)
                        .intercept(
                                chain -> {
                                    bootstrap.request((Context) chain.getArg(0));
                                    return null;
                                });
        } catch (ClassNotFoundException ignored) {
        } catch (Throwable error) {
            failure("PATCH_LOADER", error);
        }
        try {
            Class<?> root = Class.forName(HostAbi.ROOT_BACKEND, false, loader);
            Method ready = root.getDeclaredMethod("\u0d0f");
            if (installed.add(ready))
                module.hook(ready)
                        .setExceptionMode(
                                io.github.libxposed.api.XposedInterface.ExceptionMode.PASSTHROUGH)
                        .intercept(
                                chain -> {
                                    boolean value = Boolean.TRUE.equals(chain.proceed());
                                    if (value) return true;
                                    StartState state = starting.get();
                                    if (state == null) return false;
                                    if (state.deadline == 0)
                                        state.deadline = SystemClock.elapsedRealtime() + 15000;
                                    bootstrap.request(context);
                                    Object backend = HostBackend.lookup(loader);
                                    value =
                                            Boolean.TRUE.equals(
                                                    backend.getClass()
                                                            .getDeclaredMethod("\u01cb")
                                                            .invoke(backend));
                                    if (value) {
                                        module.log(
                                                Log.INFO,
                                                ModuleInfo.LOG_TAG,
                                                "ROOT_PATCH_READY elapsed_ms="
                                                        + (SystemClock.elapsedRealtime()
                                                                - state.begin));
                                        return true;
                                    }
                                    if (SystemClock.elapsedRealtime() >= state.deadline)
                                        throw new PatchWaitTimeout();
                                    return false;
                                });
            if (deoptimized.add(ready)) module.deoptimize(ready);
        } catch (ClassNotFoundException ignored) {
        } catch (Throwable error) {
            failure("ROOT_WAIT", error);
        }
        for (String[] target :
                new String[][] {
                    {"\u0915\u0dea\u0915$\u019c", "\u0d0f", "\u0dac"},
                    {"\u0412\u0de7\u0412$\u0b87", "\u0da3", "\u0da5"},
                    {"\u10a3\u0deb\u10a3$\u0d93", "\u0d0f", "\u0b94"}
                }) {
            installRunner(loader, target);
        }
    }

    private void installRunner(ClassLoader loader, String[] target) {
        try {
            Class<?> owner = Class.forName(HostAbi.PREFIX + target[0], false, loader);
            Method run = owner.getDeclaredMethod("run");
            if (!installed.add(run)) return;
            module.hook(run)
                    .setExceptionMode(
                            io.github.libxposed.api.XposedInterface.ExceptionMode.PASSTHROUGH)
                    .intercept(
                            chain -> {
                                StartState previous = starting.get();
                                StartState state =
                                        new StartState(chain.getThisObject(), target[1], target[2]);
                                starting.set(state);
                                try {
                                    bootstrap.prepareComponentForStart(context);
                                    return chain.proceed();
                                } catch (ComponentState.NotReady error) {
                                    restoreUi(state, error.userMessage);
                                    module.log(Log.WARN, ModuleInfo.LOG_TAG, error.getMessage());
                                    return null;
                                } catch (PatchWaitTimeout error) {
                                    restoreUi(state, "Root 后端未能启动，请检查 ByPassFL 日志后重试");
                                    module.log(
                                            Log.ERROR,
                                            ModuleInfo.LOG_TAG,
                                            "ROOT_START_TIMEOUT wait=15000ms backend-not-loaded");
                                    return null;
                                } catch (Throwable error) {
                                    restoreUi(state, "Root 后端未能启动，请检查 ByPassFL 日志后重试");
                                    failure("ROOT_START", error);
                                    return null;
                                } finally {
                                    if (previous == null) starting.remove();
                                    else starting.set(previous);
                                }
                            });
            module.deoptimize(run);
            module.log(Log.INFO, ModuleInfo.LOG_TAG, "ROOT_START_GUARD " + owner.getName());
        } catch (ClassNotFoundException ignored) {
        } catch (Throwable error) {
            failure("RUNNER " + target[0], error);
        }
    }

    private void restoreUi(StartState state, String message) {
        new Handler(Looper.getMainLooper())
                .post(
                        () -> {
                            try {
                                Field viewField =
                                        state.runnable.getClass().getDeclaredField("\u0bb9");
                                viewField.setAccessible(true);
                                Object button = viewField.get(state.runnable);
                                if (button instanceof View) ((View) button).setEnabled(true);
                                Field fragmentField =
                                        state.runnable
                                                .getClass()
                                                .getDeclaredField(state.fragmentField);
                                fragmentField.setAccessible(true);
                                Object fragment = fragmentField.get(state.runnable);
                                Field progressField =
                                        fragment.getClass().getDeclaredField(state.progressField);
                                progressField.setAccessible(true);
                                Object progress = progressField.get(fragment);
                                if (progress instanceof View)
                                    ((View) progress).setVisibility(View.GONE);
                            } catch (Throwable error) {
                                failure("RESTORE_UI", error);
                            }
                            UserNotice.show(context, message);
                        });
    }

    private void failure(String source, Throwable error) {
        module.log(Log.ERROR, ModuleInfo.LOG_TAG, "ROOT_HOOK_FAILED " + source, error);
    }

    private static final class StartState {
        final Object runnable;
        final String fragmentField;
        final String progressField;
        final long begin = SystemClock.elapsedRealtime();
        long deadline;

        StartState(Object runnable, String fragmentField, String progressField) {
            this.runnable = runnable;
            this.fragmentField = fragmentField;
            this.progressField = progressField;
        }
    }

    private static final class PatchWaitTimeout extends RuntimeException {}
}

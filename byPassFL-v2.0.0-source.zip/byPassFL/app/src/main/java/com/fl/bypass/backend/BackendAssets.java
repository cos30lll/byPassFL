package com.fl.bypass.backend;

import android.content.Context;
import android.util.Log;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.host.HostAbi;

import io.github.libxposed.api.XposedModule;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Verifies bundled files and stages them only inside the host's private files directory. */
final class BackendAssets {
    private final XposedModule module;
    private final Context context;
    private JSONObject manifest;

    BackendAssets(XposedModule module, Context context) {
        this.module = module;
        this.context = context;
    }

    JSONObject manifest() throws Exception {
        assets();
        return manifest;
    }

    byte[] cachedAsset(String name) throws Exception {
        JSONObject meta = assets().getJSONObject(name);
        File destination =
                new File(new File(context.getFilesDir(), ModuleInfo.BACKEND_STORAGE_DIR), name);
        if (destination.isFile() && destination.length() == meta.getLong("bytes")) {
            try (FileInputStream input = new FileInputStream(destination);
                    ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] block = new byte[8192];
                int count;
                while ((count = input.read(block)) != -1) output.write(block, 0, count);
                byte[] data = output.toByteArray();
                if (hex(MessageDigest.getInstance("SHA-256").digest(data))
                        .equals(meta.getString("sha256"))) return data;
            } catch (Exception ignored) {
            }
        }
        byte[] data = asset(name);
        atomicWrite(destination, data, false);
        info("CACHE_FILLED name=" + name + " bytes=" + data.length);
        return data;
    }

    synchronized JSONObject assets() throws Exception {
        if (manifest == null) {
            manifest =
                    new JSONObject(new String(rawAsset("manifest.json"), StandardCharsets.UTF_8));
            if (manifest.getInt("version_code") != ModuleInfo.TARGET_VERSION_CODE)
                throw new IllegalStateException("manifest version mismatch");
        }
        return manifest.getJSONObject("assets");
    }

    byte[] asset(String name) throws Exception {
        JSONObject expected = assets().getJSONObject(name);
        byte[] data = rawAsset(name);
        if (data.length != expected.getLong("bytes")
                || !hex(MessageDigest.getInstance("SHA-256").digest(data))
                        .equals(expected.getString("sha256"))) {
            throw new IllegalStateException("asset integrity failed: " + name);
        }
        return data;
    }

    private byte[] rawAsset(String name) throws Exception {
        try (ZipFile apk = new ZipFile(module.getModuleApplicationInfo().sourceDir)) {
            ZipEntry entry = apk.getEntry("assets/backend/" + name);
            if (entry == null || entry.getSize() > 4 * 1024 * 1024)
                throw new IllegalStateException("missing asset " + name);
            try (InputStream in = apk.getInputStream(entry);
                    ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] block = new byte[8192];
                int count;
                while ((count = in.read(block)) != -1) out.write(block, 0, count);
                return out.toByteArray();
            }
        }
    }

    File hostFile(String value) throws Exception {
        if (value == null) throw new IllegalArgumentException("missing destination");
        File file = new File(value).getCanonicalFile();
        String root = context.getFilesDir().getCanonicalPath() + File.separator;
        if (!file.getPath().startsWith(root))
            throw new IllegalArgumentException("destination outside host files");
        return file;
    }

    void fillCaches() throws Exception {
        cachedAsset("jed1.dex");
        byte[] component = cachedAsset("jed2.apk");
        File directory = new File(context.getFilesDir(), ModuleInfo.BACKEND_STORAGE_DIR);
        atomicWrite(new File(directory, "manifest.json"), rawAsset("manifest.json"), false);
        // 固定 1702 的组件导出路径，来自 jed1 ൡ.Ǌ 的 cp 源；即使 native 已加载也准备新版。
        atomicWrite(
                hostFile(new File(context.getFilesDir(), HostAbi.COMPONENT_EXPORT_FILE).getPath()),
                component,
                false);
        info(
                "BACKEND_COMPONENT_STAGED version="
                        + ComponentState.VERSION
                        + " bytes="
                        + component.length);
    }

    static void atomicWrite(File destination, byte[] data, boolean executable) throws Exception {
        File parent = destination.getParentFile();
        if (!parent.isDirectory() && !parent.mkdirs())
            throw new IllegalStateException("cannot create backend directory");
        File temp = File.createTempFile(".bypassfl-", ".part", parent);
        try {
            try (FileOutputStream output = new FileOutputStream(temp)) {
                output.write(data);
                output.getFD().sync();
            }
            temp.setReadable(true, true);
            temp.setExecutable(executable, true);
            if (!temp.renameTo(destination))
                throw new IllegalStateException("cannot replace backend file");
        } finally {
            if (temp.exists()) temp.delete();
        }
    }

    static String hex(byte[] value) {
        char[] result = new char[value.length * 2];
        char[] digits = "0123456789abcdef".toCharArray();
        for (int i = 0; i < value.length; i++) {
            int current = value[i] & 255;
            result[i * 2] = digits[current >>> 4];
            result[i * 2 + 1] = digits[current & 15];
        }
        return new String(result);
    }

    private void info(String value) {
        module.log(Log.INFO, ModuleInfo.LOG_TAG, value);
    }
}

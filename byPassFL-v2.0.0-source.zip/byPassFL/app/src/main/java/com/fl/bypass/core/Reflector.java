package com.fl.bypass.core;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Small reflection boundary preserving the host's original exception cause. */
public final class Reflector {
    private Reflector() {}

    public static Field field(Class<?> owner, String name) throws NoSuchFieldException {
        Field field = owner.getDeclaredField(name);
        field.setAccessible(true);
        return field;
    }

    public static Method method(Class<?> owner, String name, Class<?>... params)
            throws NoSuchMethodException {
        Method method = owner.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }

    public static Object call(Method method, Object target, Object... args) throws Throwable {
        try {
            return method.invoke(target, args);
        } catch (InvocationTargetException error) {
            throw error.getCause();
        }
    }
}

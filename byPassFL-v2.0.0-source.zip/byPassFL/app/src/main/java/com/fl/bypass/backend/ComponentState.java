package com.fl.bypass.backend;

import android.os.IBinder;
import android.os.Parcel;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.host.HostAbi;

/** 只用真实版本事务确认 system_server 组件；不触发注入或系统重启。 */
public final class ComponentState {
    private ComponentState() {}

    public static final int VERSION = ModuleInfo.COMPONENT_VERSION;
    public static final int ABSENT = -1;

    public static int version(IBinder binder) throws android.os.RemoteException {
        if (binder == null || !binder.isBinderAlive()) return ABSENT;
        Parcel data = Parcel.obtain(), reply = Parcel.obtain();
        try {
            if (!binder.transact(ModuleInfo.COMPONENT_TRANSACTION, data, reply, 0)) return 0;
            reply.readException();
            if (reply.dataAvail() < 4)
                throw new IllegalStateException("incomplete component version reply");
            return reply.readInt();
        } finally {
            data.recycle();
            reply.recycle();
        }
    }

    /** 宿主真实通道优先级：ServiceManager，缺失时才读取 MockServer 回传代理。 */
    public static Connection lookup(ClassLoader loader) throws Exception {
        Class<?> services = Class.forName(HostAbi.PREFIX + "n01", false, loader);
        IBinder direct =
                (IBinder)
                        services.getDeclaredMethod("ඈ", ClassLoader.class, String.class)
                                .invoke(
                                        null,
                                        ClassLoader.getSystemClassLoader(),
                                        HostAbi.COMPONENT_SERVICE);
        if (direct != null && direct.isBinderAlive())
            return new Connection(direct, "service-manager");
        Class<?> bridge = Class.forName("com.lerist.common.mockserver.MockServer", false, loader);
        Object remote = bridge.getDeclaredMethod("ඇ").invoke(null);
        if (remote instanceof android.os.IInterface) {
            IBinder binder = ((android.os.IInterface) remote).asBinder();
            if (binder != null && binder.isBinderAlive())
                return new Connection(binder, "mock-server");
        }
        return new Connection(null, "absent");
    }

    public static final class Connection {
        public final IBinder binder;
        public final String source;

        Connection(IBinder binder, String source) {
            this.binder = binder;
            this.source = source;
        }

        public int version() throws android.os.RemoteException {
            return ComponentState.version(binder);
        }
    }

    public static NotReady resident(int version) {
        return new NotReady(
                "BACKEND_COMPONENT_RESTART_REQUIRED version="
                        + version
                        + " expected="
                        + VERSION
                        + " resident_replaced=false",
                "系统仍驻留旧定位组件。请先重启手机，再打开 Fake Location；仅重开应用无法更新组件。");
    }

    public static final class NotReady extends IllegalStateException {
        public final String userMessage;

        public NotReady(String code, String message) {
            super(code);
            userMessage = message;
        }
    }
}

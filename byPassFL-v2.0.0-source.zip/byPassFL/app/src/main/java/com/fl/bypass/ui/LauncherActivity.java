package com.fl.bypass.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.fl.bypass.ModuleInfo;

/** 模块信息页与目标应用入口。 */
public final class LauncherActivity extends Activity {
    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        int padding = Math.round(24 * getResources().getDisplayMetrics().density);
        page.setPadding(padding, padding, padding, padding);
        TextView title = new TextView(this);
        title.setText(ModuleInfo.NAME + " " + ModuleInfo.VERSION_NAME);
        title.setTextSize(26);
        page.addView(title);
        TextView info = new TextView(this);
        info.setTextSize(16);
        info.setText(
                "目标：Fake Location "
                        + ModuleInfo.TARGET_VERSION_NAME
                        + "（"
                        + ModuleInfo.TARGET_VERSION_CODE
                        + "）\n\n"
                        + "在 LSPosed 中启用本模块，并将作用域设置为 Fake Location。\n\n"
                        + "模拟位置、路线和基站功能请以目标应用实际收到的结果为准。"
                        + "若提示定位组件版本不一致，请按提示自行更新驻留组件。\n\n"
                        + "诊断日志："
                        + ModuleInfo.LOG_TAG
                        + " / ByPassFLBackend\n");
        page.addView(info);
        Button open = new Button(this);
        open.setText("打开 Fake Location");
        open.setOnClickListener(
                view -> {
                    Intent intent =
                            getPackageManager()
                                    .getLaunchIntentForPackage(ModuleInfo.TARGET_PACKAGE);
                    if (intent == null) {
                        Toast.makeText(this, "未安装 Fake Location", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    startActivity(intent);
                });
        page.addView(open);
        scroll.addView(page);
        setContentView(scroll);
    }
}

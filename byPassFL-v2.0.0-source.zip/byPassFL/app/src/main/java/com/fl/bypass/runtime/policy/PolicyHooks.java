package com.fl.bypass.runtime.policy;

import static com.fl.bypass.core.Reflector.call;
import static com.fl.bypass.core.Reflector.field;
import static com.fl.bypass.core.Reflector.method;

import android.content.Context;
import android.os.SystemClock;
import android.util.Log;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.core.HookRegistry;
import com.fl.bypass.host.HostAbi;
import com.fl.bypass.host.PolicyScope;

import io.github.libxposed.api.XposedModule;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;

/** Scoped payload policy checks and host policy stop handling. */
public final class PolicyHooks {
    private final XposedModule module;
    private final HookRegistry hooks;
    private long lastPolicy;

    public PolicyHooks(XposedModule module) {
        this.module = module;
        this.hooks = new HookRegistry(module, "policy");
    }

    public synchronized void install(ClassLoader loader) throws Exception {
        Class<?> owner = Class.forName(HostAbi.PREFIX + "ඩޗඩ", false, loader);
        Method checker = method(owner, "ஆ", String.class);
        if (checker.getReturnType() != boolean.class)
            throw new NoSuchMethodException("policy checker ABI");
        Field context = field(owner, "ʥ"), rules = field(owner, "ළ");
        Method query =
                method(
                        Class.forName(HostAbi.PREFIX + "ຫ", false, loader),
                        "ඣ",
                        Context.class,
                        int.class);
        Method allowed =
                method(
                        Class.forName(HostAbi.PREFIX + "zp0", false, loader),
                        "ළ",
                        java.util.List.class,
                        String.class,
                        String.class);
        // payload 子类将相同策略内联进位置函数；仅在该调用线程内覆盖。
        hooks.attach(
                query,
                chain -> {
                    if (PolicyScope.active()) {
                        policyLog("MOCK_PAYLOAD_POLICY_QUERY_SCOPED");
                        return Collections.emptyList();
                    }
                    return chain.proceed();
                });
        hooks.attach(
                allowed,
                chain -> {
                    if (PolicyScope.active()) {
                        policyLog("MOCK_PAYLOAD_POLICY_STOP_SUPPRESSED");
                        return true;
                    }
                    return chain.proceed();
                });
        hooks.attach(
                checker,
                chain -> {
                    // 此入口检查活动应用黑名单；原方法失败即停止全部模拟，没有权限申请逻辑。
                    // 保留检查供诊断，停机副作用由模块移除；操作系统权限异常仍在真正 provider 调用处处理。
                    boolean denied = false;
                    try {
                        Object apps = call(query, null, context.get(chain.getThisObject()), 4);
                        if (apps instanceof java.util.List) {
                            for (Object active : (java.util.List<?>) apps) {
                                if (!Boolean.TRUE.equals(
                                        call(
                                                allowed,
                                                null,
                                                rules.get(chain.getThisObject()),
                                                active,
                                                chain.getArg(0)))) {
                                    denied = true;
                                    break;
                                }
                            }
                        }
                    } catch (Throwable error) {
                        if (error instanceof SecurityException) throw error;
                        policyLog("MOCK_POLICY_RETRY reason=" + error.getClass().getSimpleName());
                        return true;
                    }
                    if (denied) policyLog("MOCK_POLICY_STOP_SUPPRESSED");
                    return true;
                });
        hooks.deoptimize(owner);
        module.deoptimize(query);
        module.deoptimize(allowed);
    }

    private void policyLog(String message) {
        long now = SystemClock.elapsedRealtime();
        if (lastPolicy != 0 && now - lastPolicy < 30000) return;
        lastPolicy = now;
        info(message);
    }

    private void info(String message) {
        module.log(Log.INFO, ModuleInfo.LOG_TAG, message);
    }
}

package com.fl.bypass.hook;

import android.content.Context;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.runtime.MockRuntimeHooks;
import com.fl.bypass.runtime.cell.CellSimulationHooks;

import io.github.libxposed.api.XposedModule;

/** 装配宿主功能组；主进程负责后端和运行期状态，各进程保留原功能资格适配。 */
public final class HostHooks {
    private final boolean mainProcess;
    private final FeatureGateHooks features;
    private final RootStartHooks startup;
    private final MockRuntimeHooks runtime;
    private final CellSimulationHooks cells;

    public HostHooks(XposedModule module, String processName) {
        mainProcess = ModuleInfo.TARGET_PACKAGE.equals(processName);
        features = new FeatureGateHooks(module, processName);
        startup = new RootStartHooks(module);
        runtime = new MockRuntimeHooks(module);
        cells = new CellSimulationHooks(module);
    }

    public synchronized void install(ClassLoader loader, String phase) {
        if (loader == null) return;
        if (mainProcess) {
            startup.install(loader);
            runtime.install(loader);
        }
        boolean gateReady = features.install(loader, phase);
        if (mainProcess && gateReady) cells.install(loader);
    }

    public void onApplication(Context application) {
        if (mainProcess) startup.onApplication(application);
    }
}

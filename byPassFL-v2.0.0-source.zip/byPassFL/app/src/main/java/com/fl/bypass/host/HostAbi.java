package com.fl.bypass.host;

/** Raw class names verified against the Fake Location 1.5.2 / 1702 DEX ABI. */
public final class HostAbi {
    public static final String PREFIX = "androidx.appcompat.view.widget.";
    public static final String ROOT_BACKEND = PREFIX + "ʷயʷ";
    public static final String PAYLOAD_PREFIX = "ࢡࢡ.";
    public static final String PAYLOAD_ENTRY = PAYLOAD_PREFIX + "ࢡࢡࢡࢡ";
    public static final String COMPONENT_SERVICE = "service_fl_ml";
    public static final String COMPONENT_EXPORT_FILE = "2da3c574.s";

    private HostAbi() {}
}

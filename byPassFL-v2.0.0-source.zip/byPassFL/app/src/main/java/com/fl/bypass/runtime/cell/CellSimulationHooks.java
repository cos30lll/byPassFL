package com.fl.bypass.runtime.cell;

import static com.fl.bypass.core.Reflector.call;
import static com.fl.bypass.core.Reflector.field;
import static com.fl.bypass.core.Reflector.method;

import android.content.Context;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.fl.bypass.ModuleInfo;
import com.fl.bypass.core.HookRegistry;
import com.fl.bypass.core.UserNotice;
import com.fl.bypass.host.HostAbi;

import io.github.libxposed.api.XposedModule;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/** 固定1702基站开关：用户意图独立于在线查询，数据只取真实缓存或原查询回包。 */
public final class CellSimulationHooks {
    private final XposedModule module;
    private final HookRegistry hooks;
    private final Map<Object, State> states = new WeakHashMap<>();
    private final Map<Object, Request> requests = new WeakHashMap<>();
    private final ThreadLocal<Request> creating = new ThreadLocal<>();
    private final ThreadLocal<Boolean> rendering = new ThreadLocal<>();
    private Field callback, model, switchField, countField, context, prefsField;
    private Field toggleOuter, responseOuter, networkOuter;
    private Method toggle, dataChanged, readWanted, writeWanted, qualified;
    private Method nearby, setNearby, modelId, latitude, longitude, query;
    private boolean ready;

    public CellSimulationHooks(XposedModule module) {
        this.module = module;
        this.hooks = new HookRegistry(module, "cell");
    }

    public synchronized void install(ClassLoader loader) {
        if (ready || loader == null) return;
        try {
            Class<?> popup = type(loader, "ஷޚஷ"), listener = type(loader, "ஷޚஷ$ஆ");
            Class<?> response = type(loader, "ஷޚஷ$ඇ$ඈ"), network = type(loader, "ஷޚஷ$ඇ");
            Class<?> api = type(loader, "ஷޚஷ$ʥ"), location = type(loader, "එ");
            Class<?> prefs = type(loader, "ď֒ď$ʤ"), holder = type(loader, "ď֒ď");
            callback = field(popup, "ʤ");
            model = field(popup, "ʥ");
            switchField = field(popup, "ළ");
            countField = field(popup, "ඇ");
            context = field(popup, "ஆ");
            toggleOuter = field(listener, "ඈ");
            responseOuter = field(response, "ඈ");
            networkOuter = field(network, "ඈ");
            prefsField = field(holder, "Ǌ");
            readWanted = method(prefs, "ඛ");
            writeWanted = method(prefs, "ဣ", boolean.class);
            toggle = method(api, "ஆ", boolean.class);
            dataChanged = method(api, "ඈ", String.class, List.class);
            qualified = method(type(loader, "x92"), "ඓ");
            nearby = method(location, "getNearbyCells");
            setNearby = method(location, "setNearbyCells", List.class);
            modelId = method(location, "getId");
            latitude = method(location, "getLatitude");
            longitude = method(location, "getLongitude");
            query = method(popup, "Ǌ", double.class, double.class);
            Constructor<?> responseConstructor = network.getDeclaredConstructor(popup);
            responseConstructor.setAccessible(true);

            installToggleHook(listener);
            installPopupHook(popup);
            installQueryHook();
            installRequestHook(responseConstructor);
            installResponseHooks(response, loader);
            installNetworkHook(network, loader);
            installSubmitHook(loader);
            ready = true;
            info("CELL_HOOKS_READY query_controls_toggle=false hooks=" + hooks.size());
        } catch (ClassNotFoundException ignored) {
        } catch (Throwable error) {
            module.log(Log.ERROR, ModuleInfo.LOG_TAG, "CELL_HOOK_INSTALL_FAILED", error);
        }
    }

    private void installToggleHook(Class<?> listener) throws Exception {
        hooks.attach(
                method(listener, "onCheckedChanged", CompoundButton.class, boolean.class),
                chain -> {
                    if (Boolean.TRUE.equals(rendering.get())) return null;
                    CompoundButton button = (CompoundButton) chain.getArg(0);
                    if (!button.isEnabled()) return null;
                    boolean desired = Boolean.TRUE.equals(chain.getArg(1));
                    if (desired && !Boolean.TRUE.equals(call(qualified, null)))
                        return chain.proceed();
                    Object owner = toggleOuter.get(chain.getThisObject());
                    State state = state(owner);
                    state.generation++;
                    // 原宿主回调负责保存设置，并且仅在定位实际运行时发送基站列表。
                    dispatch(owner, desired);
                    Object point = model.get(owner);
                    int cached = size(point == null ? null : call(nearby, point));
                    render(owner, desired, cached, false);
                    info(
                            "CELL_TOGGLE requested="
                                    + desired
                                    + " cached_count="
                                    + cached
                                    + " data_ready="
                                    + (cached > 0));
                    if (desired && point != null && cached == 0) {
                        notice(owner, "基站开关设置已保存，当前地点暂无缓存数据，正在查询；查询失败可使用已采集的位置。");
                        if (state.inflight == 0)
                            call(query, owner, call(latitude, point), call(longitude, point));
                    }
                    return null;
                });
    }

    private void installPopupHook(Class<?> popup) throws Exception {
        hooks.attach(
                method(popup, "ඓ"),
                chain -> {
                    Object owner = chain.getThisObject(), point = model.get(owner);
                    boolean desired = wanted();
                    int cached = size(point == null ? null : call(nearby, point));
                    render(owner, desired, cached, false);
                    info("CELL_POPUP_STATE requested=" + desired + " cached_count=" + cached);
                    if (desired && point != null && cached == 0 && state(owner).inflight == 0)
                        call(query, owner, call(latitude, point), call(longitude, point));
                    return null;
                });
    }

    private void installQueryHook() throws Exception {
        hooks.attach(
                query,
                chain -> {
                    Object owner = chain.getThisObject();
                    State state = state(owner);
                    Request request =
                            new Request(
                                    owner,
                                    model.get(owner),
                                    callback.get(owner),
                                    state,
                                    ++state.sequence,
                                    state.generation);
                    state.inflight++;
                    Request previous = creating.get();
                    creating.set(request);
                    info(
                            "CELL_QUERY_BEGIN cached_count="
                                    + size(
                                            request.point == null
                                                    ? null
                                                    : call(nearby, request.point)));
                    try {
                        return chain.proceed();
                    } catch (Throwable error) {
                        complete(request);
                        failed(request, "query-entry", error.getClass().getSimpleName());
                        throw error;
                    } finally {
                        if (previous == null) creating.remove();
                        else creating.set(previous);
                        // 用户可在原网络查询完成前主动关闭；查询回包不能夺回该选择。
                        if (model.get(owner) == request.point)
                            render(owner, wanted(), count(owner), false);
                    }
                });
    }

    private void installRequestHook(Constructor<?> responseConstructor) throws Exception {
        hooks.attach(
                responseConstructor,
                chain -> {
                    Object result = chain.proceed();
                    Request request = creating.get();
                    if (request != null)
                        synchronized (requests) {
                            requests.put(chain.getThisObject(), request);
                        }
                    return result;
                });
    }

    private void installResponseHooks(Class<?> response, ClassLoader loader) throws Exception {
        hooks.attach(
                method(response, "ඈ", type(loader, "yl0"), List.class),
                chain -> {
                    Request request = request(responseOuter.get(chain.getThisObject()));
                    if (request == null) {
                        info("CELL_QUERY_CONTEXT_MISSING kind=result");
                        return chain.proceed();
                    }
                    complete(request);
                    List<?> values = (List<?>) chain.getArg(1);
                    if (values == null || values.isEmpty()) {
                        failed(request, values == null ? "null-result" : "empty-result", "none");
                        return null;
                    }
                    if (request.sequence != request.state.sequence) {
                        info("CELL_QUERY_STALE discarded=true");
                        return null;
                    }
                    List<?> actual = new ArrayList<>(values);
                    if (request.point != null) call(setNearby, request.point, actual);
                    if (request.listener != null && request.point != null)
                        call(dataChanged, request.listener, call(modelId, request.point), actual);
                    boolean desired = wanted();
                    boolean current = model.get(request.popup) == request.point;
                    if (current) {
                        if (desired) dispatch(request.popup, true);
                        render(request.popup, desired, actual.size(), false);
                    }
                    info(
                            "CELL_QUERY_RESULT count="
                                    + actual.size()
                                    + " requested="
                                    + desired
                                    + " current="
                                    + current);
                    return null;
                });
        hooks.attach(
                method(response, "ළ", int.class, String.class),
                chain -> {
                    Request request = request(responseOuter.get(chain.getThisObject()));
                    if (request == null) {
                        info("CELL_QUERY_CONTEXT_MISSING kind=business-error");
                        return chain.proceed();
                    }
                    complete(request);
                    failed(request, "business-code-" + chain.getArg(0), "none");
                    return null;
                });
    }

    private void installNetworkHook(Class<?> network, ClassLoader loader) throws Exception {
        hooks.attach(
                method(network, "ඈ", type(loader, "ڠ"), Throwable.class),
                chain -> {
                    Request request = request(chain.getThisObject());
                    if (request == null) {
                        info("CELL_QUERY_CONTEXT_MISSING kind=network-error");
                        return chain.proceed();
                    }
                    complete(request);
                    Throwable error = (Throwable) chain.getArg(1);
                    failed(
                            request,
                            "network",
                            error == null ? "null" : error.getClass().getSimpleName());
                    return null;
                });
    }

    private void installSubmitHook(ClassLoader loader) throws Exception {
        Class<?> mock = type(loader, "ŒޘŒ");
        Field remote = field(mock, "ඈ");
        hooks.attach(
                method(mock, "ǆ", List.class),
                chain -> {
                    Object result = chain.proceed();
                    info(
                            "CELL_DATA_SUBMIT count="
                                    + size(chain.getArg(0))
                                    + " backend_available="
                                    + (remote.get(chain.getThisObject()) != null));
                    return result;
                });
    }

    private Request request(Object network) {
        synchronized (requests) {
            return requests.remove(network);
        }
    }

    private State state(Object popup) {
        synchronized (states) {
            State value = states.get(popup);
            if (value == null) {
                value = new State();
                states.put(popup, value);
            }
            return value;
        }
    }

    private void complete(Request request) {
        if (request.done) return;
        request.done = true;
        request.state.inflight = Math.max(0, request.state.inflight - 1);
    }

    private void failed(Request request, String reason, String error) throws Throwable {
        boolean desired = wanted();
        int cached = size(request.point == null ? null : call(nearby, request.point));
        info(
                "CELL_QUERY_FAILED reason="
                        + reason
                        + " error="
                        + error
                        + " requested="
                        + desired
                        + " cached_count="
                        + cached);
        if (request.sequence != request.state.sequence || model.get(request.popup) != request.point)
            return;
        render(request.popup, desired, cached, true);
        if (desired && request.generation == request.state.generation)
            notice(
                    request.popup,
                    cached > 0 ? "基站查询失败，保留已缓存数据及开关设置。" : "基站查询未获得可用数据，开关设置已保留；可选择已采集基站的位置后重试。");
    }

    private boolean wanted() throws Throwable {
        return Boolean.TRUE.equals(call(readWanted, prefsField.get(null)));
    }

    private void dispatch(Object popup, boolean desired) throws Throwable {
        Object listener = callback.get(popup);
        if (listener != null) call(toggle, listener, desired);
        else call(writeWanted, prefsField.get(null), desired);
    }

    private int count(Object popup) throws Throwable {
        Object point = model.get(popup);
        return size(point == null ? null : call(nearby, point));
    }

    private void render(Object popup, boolean desired, int count, boolean failed) throws Exception {
        Boolean previous = rendering.get();
        rendering.set(true);
        try {
            Switch button = (Switch) switchField.get(popup);
            button.setEnabled(true);
            button.setChecked(desired);
            TextView label = (TextView) countField.get(popup);
            if (failed && count == 0) {
                label.setText("");
                label.setHint("暂无基站数据");
            } else label.setText(String.valueOf(count));
        } finally {
            if (previous == null) rendering.remove();
            else rendering.set(previous);
        }
    }

    private void notice(Object popup, String message) throws Exception {
        UserNotice.show((Context) context.get(popup), message);
    }

    private static Class<?> type(ClassLoader loader, String name) throws ClassNotFoundException {
        return Class.forName(HostAbi.PREFIX + name, false, loader);
    }

    private static int size(Object values) {
        return values instanceof List ? ((List<?>) values).size() : 0;
    }

    private void info(String message) {
        module.log(Log.INFO, ModuleInfo.LOG_TAG, message);
    }

    private static final class State {
        long sequence, generation;
        int inflight;
    }

    private static final class Request {
        final Object popup, point, listener;
        final State state;
        final long sequence, generation;
        boolean done;

        Request(
                Object popup,
                Object point,
                Object listener,
                State state,
                long sequence,
                long generation) {
            this.popup = popup;
            this.point = point;
            this.listener = listener;
            this.state = state;
            this.sequence = sequence;
            this.generation = generation;
        }
    }
}

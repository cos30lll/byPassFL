# 后端本地依赖

项目运行依赖固定 Fake Location 1.5.2 / 1702 的动态 DEX 和 native assets。它们不属于项目自有 Java/Python 源码，GitHub 源码清单不收录二进制副本；本地完整工作区已有这些依赖。

## 目录

- `backend/inputs/jed1.dex`：原始解码载荷 DEX。
- `backend/inputs/jed2.apk`：原始定位组件 APK。
- `backend/inputs/native/libfl_init*.so`：原始 native 加载器。
- `app/src/main/assets/backend/native/`：目标 APK 中的 native 资源，最终加载器由绑定工具生成。
- `input-manifest.json`：输入文件名、固定哈希和版本要求。

`jed1` 和 `jed2` 必须是输入清单中的原始解码产物，不能用已修改的模块内置副本替代。动态 DEX 的提取不属于公开构建脚本的职责；原始 DEX 的 source/账号配置不得混入依赖目录。

## 导入与生成

```sh
python3 -B tools/backend/import_assets.py \
  --host-apk /path/to/FakeLocation-1.5.2.apk \
  --jed1 /path/to/original-jed1.dex \
  --jed2 /path/to/original-jed2.apk

export BYPASSFL_SDK=/path/to/android-sdk
export BYPASSFL_DEXLIB_JAR=/path/to/jadx-1.5.6-all.jar
python3 -B tools/backend/prepare_backend.py
python3 -B tools/verify/check_backend.py
```

输入哈希验证全部通过后才落盘。生成工具只改写本地副本，组件辅助类使用 `com.fl.bypass.component`；native 内容校验片段、SONAME 与 manifest 同步更新。原始输入不变。

若已经有完整本地后端资源，只需重新生成。生成报告写入 `build/reports/`，资源逐项 SHA-256 和大小保存在后端 `manifest.json`。重复的 `jed1.zip` 已移除，载荷统一保留 `jed1.dex`。

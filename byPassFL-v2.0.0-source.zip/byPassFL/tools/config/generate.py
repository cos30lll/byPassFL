#!/usr/bin/env python3
"""Generate build-only identity, metadata, and component constants from module.properties."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.project import ROOT, properties


def generate(output):
    values = properties()
    namespace = values["applicationId"]
    fields = {
        "NAME": ("String", values["name"]),
        "APPLICATION_ID": ("String", namespace),
        "VERSION_NAME": ("String", values["versionName"]),
        "VERSION_CODE": ("int", values["versionCode"]),
        "TARGET_PACKAGE": ("String", values["targetPackage"]),
        "TARGET_VERSION_NAME": ("String", values["targetVersionName"]),
        "TARGET_VERSION_CODE": ("int", values["targetVersionCode"]),
        "COMPONENT_VERSION": ("int", values["componentVersion"]),
        "COMPONENT_TRANSACTION": ("int", values["componentTransaction"]),
        "LOG_TAG": ("String", values["logTag"]),
        "BACKEND_STORAGE_DIR": ("String", values["id"] + "/backend"),
    }
    java = ["package " + namespace + ";", "", "/** Generated from module.properties. */", "public final class ModuleInfo {"]
    for name, (kind, value) in fields.items():
        literal = '"' + value + '"' if kind == "String" else value
        java.append("    public static final " + kind + " " + name + " = " + literal + ";")
    java.extend(["    private ModuleInfo() {}", "}", ""])
    path = output / "java" / Path(namespace.replace(".", "/")) / "ModuleInfo.java"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(java), encoding="utf-8")
    metadata = output / "resources/META-INF/xposed"
    metadata.mkdir(parents=True, exist_ok=True)
    (metadata / "java_init.list").write_text(values["entryClass"] + "\n")
    (metadata / "scope.list").write_text(values["targetPackage"] + "\n")
    keys = ["id", "name", "author", "description", "minApiVersion", "targetApiVersion"]
    props = [key + "=" + values[key] for key in keys]
    props += ["version=" + values["versionName"], "versionCode=" + values["versionCode"]]
    (metadata / "module.prop").write_text("\n".join(props) + "\n")
    helper = output / "component/com/fl/bypass/component/ComponentConfig.java"
    helper.parent.mkdir(parents=True, exist_ok=True)
    helper.write_text("package com.fl.bypass.component;\npublic final class ComponentConfig {\n"
                      + "    public static final int VERSION = " + values["componentVersion"] + ";\n"
                      + "    public static final int TRANSACTION = " + values["componentTransaction"] + ";\n"
                      + "    private ComponentConfig() {}\n}\n")
    return output


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "build/generated/module"
    generate(target)
    print("MODULE_METADATA_OK", target)

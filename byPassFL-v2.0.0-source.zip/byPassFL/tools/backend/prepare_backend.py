#!/usr/bin/env python3
"""Rebuild the bundled backend and refresh component/native integrity binding."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.project import ROOT, properties, write_json, sdk_path
from config.generate import generate
from backend.prepare_native import bind_native_assets

def main():
    project = ROOT
    config = properties()
    source = project / 'backend/inputs'
    out = project / 'app/src/main/assets/backend'
    build = project / 'build/backend'
    jar_value = os.environ.get('BYPASSFL_DEXLIB_JAR')
    if not jar_value:
        raise SystemExit('Set BYPASSFL_DEXLIB_JAR to the JADX 1.5.6 all-deps JAR or a compatible dexlib2 classpath')
    jar = Path(jar_value)
    for folder in [out, build]:
        folder.mkdir(parents=True, exist_ok=True)
    expected = {'jed1.dex': '6ee9e727439393267bb172a900ad8c3952740700b74991a1241b430e50fddb2c',
                'jed2.apk': 'c90f2d672c837fe10743e52dd92fd5c71338c212745d12b14cf0d934509949ff'}
    for name, digest in expected.items():
        assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest, name
    subprocess.run(['javac', '-encoding', 'UTF-8', '-cp', str(jar), '-d', str(build),
                    str(project / 'tools/backend/PatchDex.java')], check=True)
    subprocess.run(['java', '-cp', str(jar) + ':' + str(build), 'PatchDex', 'jed1',
                    str(source / 'jed1.dex'), str(out / 'jed1.dex')], check=True)
    with zipfile.ZipFile(source / 'jed2.apk') as archive:
        (build / 'jed2-original.dex').write_bytes(archive.read('classes.dex'))
    sdk = sdk_path()
    generated = generate(build / 'generated')
    helper = build / 'helper'
    helper.mkdir(parents=True, exist_ok=True)
    subprocess.run(['javac', '--release', '8', '-encoding', 'UTF-8', '-cp', str(sdk / ('platforms/android-' + config['compileSdk'] + '/android.jar')),
                    '-d', str(helper), str(project / 'component/src/main/java/com/fl/bypass/component/ComponentVersion.java'),
                    str(generated / 'component/com/fl/bypass/component/ComponentConfig.java')], check=True)
    subprocess.run(['java', '-cp', str(sdk / ('build-tools/' + config['buildTools'] + '/lib/d8.jar')), 'com.android.tools.r8.D8',
                    '--min-api', '26', '--lib', str(sdk / ('platforms/android-' + config['compileSdk'] + '/android.jar')), '--output', str(helper),
                    str(helper / 'com/fl/bypass/component/ComponentVersion.class'),
                    str(helper / 'com/fl/bypass/component/ComponentConfig.class')], check=True)
    subprocess.run(['java', '-cp', str(jar) + ':' + str(build), 'PatchDex', 'jed2',
                    str(build / 'jed2-original.dex'), str(build / 'jed2.dex'), str(helper / 'classes.dex')], check=True)
    with zipfile.ZipFile(source / 'jed2.apk') as original, zipfile.ZipFile(out / 'jed2.apk', 'w', zipfile.ZIP_DEFLATED) as changed:
        for entry in original.infolist():
            if entry.filename.startswith('META-INF/'):
                continue  # 注入用 APK 不经 pm 安装；去掉已失效的旧签名。
            changed.writestr(entry.filename, (build / 'jed2.dex').read_bytes()
                             if entry.filename == 'classes.dex' else original.read(entry))
    native_binding = bind_native_assets(project, write=True)
    write_json(project / 'build/reports/native-binding.json', native_binding)
    # jed1.zip was an unused duplicate of jed1.dex and is no longer packaged.
    legacy_zip = out / 'jed1.zip'
    if legacy_zip.exists():
        legacy_zip.unlink()
    manifest = {'target': config['targetPackage'], 'version_code': int(config['targetVersionCode']),
                'entry': 'ࢡࢡ.ࢡࢡࢡࢡ', 'entry_method': 'ࢡࢡ', 'format': 2,
                'component_version': int(config['componentVersion']), 'module_version': config['versionName'], 'exclusion_policy': 'disabled',
                'original_hashes': expected, 'native_binding': native_binding, 'assets': {}}
    for f in sorted(out.rglob('*')):
        if f.is_file() and f.name != 'manifest.json':
            manifest['assets'][str(f.relative_to(out))] = {
                'bytes': f.stat().st_size, 'sha256': hashlib.sha256(f.read_bytes()).hexdigest()}
    assert manifest['assets'].get('native/libfl_init64.so')
    assert manifest['assets'].get('native/liblh64.so')
    (out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print('BACKEND_ASSETS_OK', len(manifest['assets']))


if __name__ == "__main__":
    main()

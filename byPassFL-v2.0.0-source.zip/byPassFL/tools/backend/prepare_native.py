#!/usr/bin/env python3
"""将原生入口的数据校验值与内置组件绑定；不修改指令或调用者签名检查。"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.project import properties, write_json

import argparse
import hashlib
import json
import struct

ORIGINALS = {
    'libfl_init.so': 'b80b9b58de60f5cbb56bacbdc417926c4bb54143b1cc9bf5e689dac6a5839c4a',
    'libfl_init64.so': '278141043d7959fcd3729947d5524139ab315ceb9d51795995cc644355bd9354',
    'libfl_initx.so': '907fbfb16b481feeb7be41860a463a0ed9e2f5d6d7986c77ae89a226fa024477',
    'libfl_initx64.so': '15bf5773dfd111ec5205987f9f2fd59f9bf2b79f7d78e484913ba6f5460ca8d0',
}
ORIGINAL_FRAGMENT = b'4b3abbcd56e'
ORIGINAL_SONAME = b'libfakeloc_init.so'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def sections(data):
    """只读 ELF section 布局，确认全部可执行段保持原样。"""
    assert data[:4] == b'\x7fELF' and data[5] == 1
    if data[4] == 2:
        offset = struct.unpack_from('<Q', data, 40)[0]
        step, count = struct.unpack_from('<HH', data, 58)
        layout = '<IIQQQQIIQQ'
    else:
        assert data[4] == 1
        offset = struct.unpack_from('<I', data, 32)[0]
        step, count = struct.unpack_from('<HH', data, 46)
        layout = '<IIIIIIIIII'
    for i in range(count):
        values = struct.unpack_from(layout, data, offset + step * i)
        yield values[2], values[4], values[5]


def bind_native_assets(project, write=False):
    assets = project / 'app/src/main/assets/backend'
    component = (assets / 'jed2.apk').read_bytes()
    original_component = (project / 'backend/inputs/jed2.apk').read_bytes()
    original_md5 = hashlib.md5(original_component).hexdigest()
    assert original_md5 == 'a6de0dbfb0a0b54b3abbcd56e05a1c25'
    component_md5 = hashlib.md5(component).hexdigest()
    fragment = component_md5[14:25].encode('ascii')
    assert original_md5[14:25].encode() == ORIGINAL_FRAGMENT
    records = []
    for name, expected in ORIGINALS.items():
        original = (project / 'backend/inputs/native' / name).read_bytes()
        assert sha(original) == expected, 'unknown original native input: ' + name
        assert original.count(ORIGINAL_FRAGMENT + b'\0') == 1
        assert original.count(ORIGINAL_SONAME + b'\0') == 1
        # 等长 SONAME 保持 ELF 布局；内容绑定确保修改组件后不会复用旧入口句柄。
        soname = ('libsec' + sha(original + component)[:9] + '.so').encode('ascii')
        assert len(soname) == len(ORIGINAL_SONAME)
        changes = [(original.index(ORIGINAL_FRAGMENT + b'\0'), ORIGINAL_FRAGMENT, fragment),
                   (original.index(ORIGINAL_SONAME + b'\0'), ORIGINAL_SONAME, soname)]
        result = bytearray(original)
        allowed = set()
        for offset, before, after in changes:
            assert len(before) == len(after)
            assert original[offset:offset + len(before)] == before
            result[offset:offset + len(before)] = after
            allowed.update(range(offset, offset + len(before)))
        result = bytes(result)
        assert len(result) == len(original)
        assert all(a == b or i in allowed for i, (a, b) in enumerate(zip(original, result)))
        for flags, offset, size in sections(original):
            if flags & 4:  # SHF_EXECINSTR
                assert original[offset:offset + size] == result[offset:offset + size], 'instruction changed'
        target = assets / 'native' / name
        if write:
            target.write_bytes(result)
        else:
            assert target.read_bytes() == result, 'native/component binding stale: ' + name
        records.append({'asset': 'native/' + name, 'original_sha256': expected,
                        'sha256': sha(result), 'soname': soname.decode(),
                        'digest_offset': changes[0][0], 'soname_offset': changes[1][0],
                        'executable_sections_unchanged': True})
    return {'module_version': properties()['versionName'], 'component_version': int(properties()['componentVersion']),
            'component_sha256': sha(component), 'component_md5': component_md5,
            'digest_fragment': fragment.decode(), 'original_digest_fragment': ORIGINAL_FRAGMENT.decode(),
            'original_gate_accepts_component': ORIGINAL_FRAGMENT.decode() in component_md5,
            'bound_gate_accepts_component': fragment.decode() in component_md5,
            'libraries': records, 'result': 'PASS', 'runtime_validation': 'pending user device test'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write', action='store_true', help='write bound native copies and refresh manifest')
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[2]
    report = bind_native_assets(project, write=args.write)
    if args.write:
        assets = project / 'app/src/main/assets/backend'
        manifest_file = assets / 'manifest.json'
        info = json.loads(manifest_file.read_text())
        info['native_binding'] = report
        for record in report['libraries']:
            data = (assets / record['asset']).read_bytes()
            info['assets'][record['asset']] = {'bytes': len(data), 'sha256': sha(data)}
        manifest_file.write_text(json.dumps(info, ensure_ascii=False, indent=2) + '\n')
    write_json(project / 'build/reports/native-binding.json', report)
    print('NATIVE_BINDING_PASS libraries=4 executable_sections_unchanged=true component_md5=' + report['component_md5'])


if __name__ == '__main__':
    main()
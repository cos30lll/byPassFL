#!/usr/bin/env python3
"""Prepare local vendor inputs from an original APK and two previously extracted payloads."""
import argparse
from pathlib import Path
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.project import ROOT, sha256, write_json

PAYLOADS = {
    "jed1.dex": "6ee9e727439393267bb172a900ad8c3952740700b74991a1241b430e50fddb2c",
    "jed2.apk": "c90f2d672c837fe10743e52dd92fd5c71338c212745d12b14cf0d934509949ff",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host-apk", type=Path, required=True)
    parser.add_argument("--jed1", type=Path, required=True)
    parser.add_argument("--jed2", type=Path, required=True)
    args = parser.parse_args()
    manifest = __import__("json").loads((ROOT / "backend/input-manifest.json").read_text())
    original_native = {record["path"]: record["sha256"] for record in manifest["native_assets"]}
    staged = {}
    for name, path in [("jed1.dex", args.jed1), ("jed2.apk", args.jed2)]:
        data = path.read_bytes()
        if sha256(data) != PAYLOADS[name]:
            raise RuntimeError("Unexpected payload hash: " + name)
        staged["backend/inputs/" + name] = data
    with zipfile.ZipFile(args.host_apk) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("Invalid host APK")
        for name, expected in original_native.items():
            source = "assets/" + Path(name).name
            try:
                data = archive.read(source)
            except KeyError as error:
                raise RuntimeError("Missing original APK entry: " + source) from error
            if sha256(data) != expected:
                raise RuntimeError("Unexpected native hash: " + name)
            staged["app/src/main/assets/backend/" + name] = data
            if Path(name).name.startswith("libfl_init"):
                staged["backend/inputs/" + name] = data
    for relative, data in staged.items():
        destination = ROOT / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
    write_json(ROOT / "build/reports/imported-inputs.json",
               {"files": len(staged), "source_apk_sha256": sha256(args.host_apk.read_bytes()), "result": "PASS"})
    print("BACKEND_INPUTS_READY files=" + str(len(staged)))


if __name__ == "__main__":
    main()
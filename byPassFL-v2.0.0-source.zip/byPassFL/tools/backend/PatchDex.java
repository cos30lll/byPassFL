import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.builder.*;
import com.android.tools.smali.dexlib2.builder.instruction.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.immutable.ImmutableDexFile;
import com.android.tools.smali.dexlib2.immutable.ImmutableMethod;
import com.android.tools.smali.dexlib2.immutable.ImmutableMethodImplementation;
import com.android.tools.smali.dexlib2.immutable.instruction.*;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableMethodReference;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableStringReference;
import com.android.tools.smali.dexlib2.rewriter.*;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/** 仅重写工程内置副本；用 dexlib2 重建 try/debug/code/map，原始取证 DEX 保持不变。 */
public final class PatchDex {
    private static final String HELPER = "Lcom/fl/bypass/component/ComponentVersion;";

    private static ImmutableMethodReference ref(
            String owner, String name, String result, String... args) {
        return new ImmutableMethodReference(owner, name, Arrays.asList(args), result);
    }

    private static BuilderInstruction35c invoke(String owner, String name, String result) {
        return new BuilderInstruction35c(
                Opcode.INVOKE_STATIC, 0, 0, 0, 0, 0, 0, ref(owner, name, result));
    }

    private static void stage(MethodImplementationBuilder b, String value) {
        b.addInstruction(
                new BuilderInstruction21c(
                        Opcode.CONST_STRING, 0, new ImmutableStringReference(value)));
        b.addInstruction(
                new BuilderInstruction35c(
                        Opcode.INVOKE_STATIC,
                        1,
                        0,
                        0,
                        0,
                        0,
                        0,
                        ref(HELPER, "stage", "V", "Ljava/lang/String;")));
    }

    private static MethodImplementation startBody() {
        MethodImplementationBuilder b = new MethodImplementationBuilder(3);
        Label begin = b.addLabel("begin");
        stage(b, "caller-check");
        b.addInstruction(invoke("Lࢡ/ޔ;", "Ԩ", "V"));
        stage(b, "policy-check");
        b.addInstruction(invoke("Lࢡ/ޛ;", "ՠ", "Z"));
        b.addInstruction(new BuilderInstruction11x(Opcode.MOVE_RESULT, 0));
        b.addInstruction(
                new BuilderInstruction22c(
                        Opcode.IPUT_BOOLEAN,
                        0,
                        2,
                        new com.android.tools.smali.dexlib2.immutable.reference
                                .ImmutableFieldReference("Lࢡ/ތ;", "Ϳ", "Z")));
        b.addInstruction(new BuilderInstruction21t(Opcode.IF_NEZ, 0, b.getLabel("init")));
        b.addInstruction(
                new BuilderInstruction35c(
                        Opcode.INVOKE_STATIC,
                        1,
                        0,
                        0,
                        0,
                        0,
                        0,
                        ref(HELPER, "startResult", "V", "Z")));
        b.addInstruction(new BuilderInstruction10x(Opcode.RETURN_VOID));
        b.addLabel("init");
        stage(b, "native-init");
        b.addInstruction(
                new BuilderInstruction21c(
                        Opcode.SGET_BOOLEAN,
                        0,
                        new com.android.tools.smali.dexlib2.immutable.reference
                                .ImmutableFieldReference("Lࢡ/ފ;", "ޟ", "Z")));
        b.addInstruction(new BuilderInstruction21t(Opcode.IF_NEZ, 0, b.getLabel("start")));
        b.addInstruction(invoke("Lࢡ/އ;", "Ϳ", "Landroid/content/Context;"));
        b.addInstruction(new BuilderInstruction11x(Opcode.MOVE_RESULT_OBJECT, 0));
        b.addInstruction(
                new BuilderInstruction35c(
                        Opcode.INVOKE_STATIC,
                        1,
                        0,
                        0,
                        0,
                        0,
                        0,
                        ref(
                                HELPER,
                                "requireContext",
                                "Landroid/content/Context;",
                                "Landroid/content/Context;")));
        b.addInstruction(new BuilderInstruction11x(Opcode.MOVE_RESULT_OBJECT, 0));
        b.addInstruction(
                new BuilderInstruction35c(
                        Opcode.INVOKE_STATIC,
                        1,
                        0,
                        0,
                        0,
                        0,
                        0,
                        ref("Lࢡ/ފ;", "init", "V", "Landroid/content/Context;")));
        b.addInstruction(
                new BuilderInstruction35c(
                        Opcode.INVOKE_VIRTUAL,
                        1,
                        0,
                        0,
                        0,
                        0,
                        0,
                        ref(
                                "Landroid/content/Context;",
                                "getClassLoader",
                                "Ljava/lang/ClassLoader;")));
        b.addInstruction(new BuilderInstruction11x(Opcode.MOVE_RESULT_OBJECT, 1));
        b.addInstruction(
                new BuilderInstruction35c(
                        Opcode.INVOKE_STATIC,
                        1,
                        1,
                        0,
                        0,
                        0,
                        0,
                        ref("Lࢡ/ޝ;", "hook", "V", "Ljava/lang/ClassLoader;")));
        b.addInstruction(
                new BuilderInstruction35c(
                        Opcode.INVOKE_VIRTUAL,
                        1,
                        0,
                        0,
                        0,
                        0,
                        0,
                        ref(
                                "Landroid/content/Context;",
                                "getClassLoader",
                                "Ljava/lang/ClassLoader;")));
        b.addInstruction(new BuilderInstruction11x(Opcode.MOVE_RESULT_OBJECT, 0));
        b.addInstruction(
                new BuilderInstruction35c(
                        Opcode.INVOKE_STATIC,
                        1,
                        0,
                        0,
                        0,
                        0,
                        0,
                        ref("Lࢡ/ޙ;", "hook", "V", "Ljava/lang/ClassLoader;")));
        b.addLabel("start");
        stage(b, "native-start");
        b.addInstruction(invoke("Lࢡ/ފ;", "startMockLocation", "V"));
        b.addInstruction(invoke("Lࢡ/ފ;", "isMocking", "Z"));
        b.addInstruction(new BuilderInstruction11x(Opcode.MOVE_RESULT, 0));
        b.addInstruction(
                new BuilderInstruction35c(
                        Opcode.INVOKE_STATIC,
                        1,
                        0,
                        0,
                        0,
                        0,
                        0,
                        ref(HELPER, "startResult", "V", "Z")));
        b.addInstruction(new BuilderInstruction10x(Opcode.RETURN_VOID));
        Label end = b.addLabel("end");
        Label handler = b.addLabel("handler");
        b.addInstruction(new BuilderInstruction11x(Opcode.MOVE_EXCEPTION, 0));
        b.addInstruction(
                new BuilderInstruction35c(
                        Opcode.INVOKE_STATIC,
                        1,
                        0,
                        0,
                        0,
                        0,
                        0,
                        ref(HELPER, "startFailed", "V", "Ljava/lang/Throwable;")));
        b.addInstruction(new BuilderInstruction10x(Opcode.RETURN_VOID));
        b.addCatch("Ljava/lang/Exception;", begin, end, handler);
        return b.getMethodImplementation();
    }

    private static final long EXPIRY = 4102444799000L;

    public static void main(String[] args) throws Exception {
        String mode = args[0];
        DexFile input = DexFileFactory.loadDexFile(args[1], Opcodes.getDefault());
        AtomicInteger changed = new AtomicInteger();
        AtomicInteger timing = new AtomicInteger();
        AtomicInteger versionTransactions = new AtomicInteger();
        AtomicInteger stopLogs = new AtomicInteger();
        AtomicInteger contexts = new AtomicInteger();
        AtomicInteger starts = new AtomicInteger();
        AtomicInteger exclusionMatchers = new AtomicInteger();
        DexRewriter rewriter =
                new DexRewriter(
                        new RewriterModule() {
                            @Override
                            public Rewriter<Method> getMethodRewriter(Rewriters rw) {
                                return m -> {
                                    MethodImplementation old = m.getImplementation();
                                    if (old == null) return m;
                                    String c = m.getDefiningClass(), n = m.getName();
                                    String result = null;
                                    if ("jed1".equals(mode)) {
                                        if (Arrays.asList("Lࢡࢡ/ǆ;", "Lࢡࢡ/Ѹ;", "Lࢡࢡ/ࡗ;").contains(c)
                                                && "run".equals(n)
                                                && m.getParameterTypes().isEmpty()) result = "void";
                                    } else if ("Lࢡ/ޛ;".equals(c)) {
                                        if (Arrays.asList("ԫ", "Ԭ").contains(n)) result = "long";
                                        else if ("ԭ".equals(n)) result = "string";
                                        else if ("ՠ".equals(n)) result = "true";
                                        else if (Arrays.asList("Ԯ", "ԯ", "ֈ").contains(n))
                                            result = "false";
                                        else if (Arrays.asList("֏", "ׯ").contains(n))
                                            result = "void";
                                    }
                                    // 单一排除名单谓词供定位与电话信息分支共用。
                                    // 保留调用者的空包名拒绝与用户 setAllowMockPackages 白名单。
                                    if ("jed2".equals(mode) && "Lࢡ/Ԫ;".equals(c) && "ԩ".equals(n)) {
                                        if (!"Z".equals(m.getReturnType())
                                                || !m.getParameterTypes()
                                                        .equals(
                                                                Arrays.asList(
                                                                        "Ljava/util/List;",
                                                                        "Ljava/lang/String;",
                                                                        "Ljava/lang/String;"))
                                                || (m.getAccessFlags() & 8) == 0) {
                                            throw new IllegalStateException(
                                                    "exclusion matcher ABI mismatch: " + m);
                                        }
                                        result = "true";
                                        exclusionMatchers.incrementAndGet();
                                        System.out.println(
                                                "EXCLUSION_MATCHER_REMOVED "
                                                        + c
                                                        + "->"
                                                        + n
                                                        + " user_allowlist=preserved");
                                    }
                                    MethodImplementation next = old;
                                    if (result != null) {
                                        List<Instruction> code = new ArrayList<>();
                                        int registers = Math.max(old.getRegisterCount(), 2);
                                        switch (result) {
                                            case "void":
                                                code.add(
                                                        new ImmutableInstruction10x(
                                                                Opcode.RETURN_VOID));
                                                break;
                                            case "long":
                                                code.add(
                                                        new ImmutableInstruction51l(
                                                                Opcode.CONST_WIDE, 0, EXPIRY));
                                                code.add(
                                                        new ImmutableInstruction11x(
                                                                Opcode.RETURN_WIDE, 0));
                                                break;
                                            case "string":
                                                code.add(
                                                        new ImmutableInstruction21c(
                                                                Opcode.CONST_STRING,
                                                                0,
                                                                new ImmutableStringReference("1")));
                                                code.add(
                                                        new ImmutableInstruction11x(
                                                                Opcode.RETURN_OBJECT, 0));
                                                break;
                                            default:
                                                code.add(
                                                        new ImmutableInstruction11n(
                                                                Opcode.CONST_4,
                                                                0,
                                                                "true".equals(result) ? 1 : 0));
                                                code.add(
                                                        new ImmutableInstruction11x(
                                                                Opcode.RETURN, 0));
                                                break;
                                        }
                                        next =
                                                new ImmutableMethodImplementation(
                                                        registers,
                                                        code,
                                                        Collections.emptyList(),
                                                        Collections.emptyList());
                                        changed.incrementAndGet();
                                        System.out.println(
                                                "METHOD_PATCH "
                                                        + c
                                                        + "->"
                                                        + n
                                                        + " result="
                                                        + result);
                                    } else if ("jed1".equals(mode)
                                            && Arrays.asList("Lࢡࢡ/ࢡࢡࢡࢡ;", "Lࢡࢡ/ൡ;").contains(c)) {
                                        List<Instruction> code = new ArrayList<>();
                                        boolean edited = false;
                                        for (Instruction i : old.getInstructions()) {
                                            if (i.getOpcode() == Opcode.CONST_WIDE
                                                    && i instanceof WideLiteralInstruction
                                                    && ((WideLiteralInstruction) i).getWideLiteral()
                                                            == 1787216781230L) {
                                                code.add(
                                                        new ImmutableInstruction51l(
                                                                Opcode.CONST_WIDE,
                                                                ((OneRegisterInstruction) i)
                                                                        .getRegisterA(),
                                                                EXPIRY));
                                                timing.incrementAndGet();
                                                edited = true;
                                            } else code.add(i);
                                        }
                                        if (edited)
                                            next =
                                                    new ImmutableMethodImplementation(
                                                            old.getRegisterCount(),
                                                            code,
                                                            old.getTryBlocks(),
                                                            old.getDebugItems());
                                    }
                                    if ("jed2".equals(mode)
                                            && "Lࢡ/ށ$Ϳ;".equals(c)
                                            && "onTransact".equals(n)) {
                                        if (!m.getParameterTypes()
                                                        .equals(
                                                                Arrays.asList(
                                                                        "I",
                                                                        "Landroid/os/Parcel;",
                                                                        "Landroid/os/Parcel;",
                                                                        "I"))
                                                || old.getRegisterCount() < 6)
                                            throw new IllegalStateException(
                                                    "component ABI mismatch");
                                        MutableMethodImplementation mutable =
                                                new MutableMethodImplementation(next);
                                        Label original = mutable.newLabelForIndex(0);
                                        int first = old.getRegisterCount() - 4;
                                        mutable.addInstruction(
                                                0,
                                                new BuilderInstruction3rc(
                                                        Opcode.INVOKE_STATIC_RANGE,
                                                        first,
                                                        3,
                                                        new ImmutableMethodReference(
                                                                "Lcom/fl/bypass/component/ComponentVersion;",
                                                                "dispatch",
                                                                Arrays.asList(
                                                                        "I",
                                                                        "Landroid/os/Parcel;",
                                                                        "Landroid/os/Parcel;"),
                                                                "Z")));
                                        mutable.addInstruction(
                                                1,
                                                new BuilderInstruction11x(Opcode.MOVE_RESULT, 0));
                                        mutable.addInstruction(
                                                2,
                                                new BuilderInstruction21t(
                                                        Opcode.IF_EQZ, 0, original));
                                        mutable.addInstruction(
                                                3, new BuilderInstruction11x(Opcode.RETURN, 0));
                                        next = mutable;
                                        versionTransactions.incrementAndGet();
                                        System.out.println("VERSION_TRANSACTION " + c + "->" + n);
                                    }
                                    if ("jed2".equals(mode)
                                            && "Lࢡ/ފ;".equals(c)
                                            && "stopMockLocation".equals(n)) {
                                        List<Instruction> code = new ArrayList<>();
                                        code.add(
                                                new ImmutableInstruction21c(
                                                        Opcode.CONST_STRING,
                                                        0,
                                                        new ImmutableStringReference(
                                                                "native-stop-or-init-error")));
                                        code.add(
                                                new ImmutableInstruction35c(
                                                        Opcode.INVOKE_STATIC,
                                                        1,
                                                        0,
                                                        0,
                                                        0,
                                                        0,
                                                        0,
                                                        new ImmutableMethodReference(
                                                                "Lcom/fl/bypass/component/ComponentVersion;",
                                                                "logStop",
                                                                Arrays.asList("Ljava/lang/String;"),
                                                                "V")));
                                        for (Instruction i : next.getInstructions()) code.add(i);
                                        if (!next.getTryBlocks().isEmpty())
                                            throw new IllegalStateException(
                                                    "stop has unexpected try blocks");
                                        next =
                                                new ImmutableMethodImplementation(
                                                        Math.max(1, next.getRegisterCount()),
                                                        code,
                                                        Collections.emptyList(),
                                                        Collections.emptyList());
                                        stopLogs.incrementAndGet();
                                    }
                                    if ("jed2".equals(mode)
                                            && "Lࢡ/ޔ;".equals(c)
                                            && "Ԩ".equals(n)
                                            && m.getParameterTypes().isEmpty()) {
                                        MutableMethodImplementation mutable =
                                                new MutableMethodImplementation(next);
                                        int found = 0;
                                        for (int i = 0; i < mutable.getInstructions().size(); i++) {
                                            Instruction insn = mutable.getInstructions().get(i);
                                            if (!(insn instanceof ReferenceInstruction)
                                                    || !((ReferenceInstruction) insn)
                                                            .getReference()
                                                            .toString()
                                                            .equals(
                                                                    "Landroid/app/ActivityThread;->currentApplication()Landroid/app/Application;"))
                                                continue;
                                            int reg =
                                                    ((OneRegisterInstruction)
                                                                    mutable.getInstructions()
                                                                            .get(i + 1))
                                                            .getRegisterA();
                                            mutable.replaceInstruction(
                                                    i,
                                                    invoke(
                                                            "Lࢡ/އ;",
                                                            "Ϳ",
                                                            "Landroid/content/Context;"));
                                            mutable.addInstruction(
                                                    i + 2,
                                                    new BuilderInstruction35c(
                                                            Opcode.INVOKE_STATIC,
                                                            1,
                                                            reg,
                                                            0,
                                                            0,
                                                            0,
                                                            0,
                                                            ref(
                                                                    HELPER,
                                                                    "requireContext",
                                                                    "Landroid/content/Context;",
                                                                    "Landroid/content/Context;")));
                                            mutable.addInstruction(
                                                    i + 3,
                                                    new BuilderInstruction11x(
                                                            Opcode.MOVE_RESULT_OBJECT, reg));
                                            found++;
                                            i += 3;
                                        }
                                        if (found != 1)
                                            throw new IllegalStateException(
                                                    "caller Context callsite mismatch: " + found);
                                        next = mutable;
                                        contexts.incrementAndGet();
                                        System.out.println(
                                                "CALLER_CONTEXT_PATCH "
                                                        + c
                                                        + "->"
                                                        + n
                                                        + " signature_check=preserved");
                                    }
                                    if ("jed2".equals(mode)
                                            && "Lࢡ/ތ;".equals(c)
                                            && "ރ".equals(n)
                                            && m.getParameterTypes().isEmpty()) {
                                        if (old.getRegisterCount() != 3)
                                            throw new IllegalStateException(
                                                    "start register layout mismatch");
                                        next = startBody();
                                        starts.incrementAndGet();
                                        System.out.println("START_DIAGNOSTICS " + c + "->" + n);
                                    }
                                    if (next == old) return m;
                                    return new ImmutableMethod(
                                            c,
                                            n,
                                            m.getParameters(),
                                            m.getReturnType(),
                                            m.getAccessFlags(),
                                            m.getAnnotations(),
                                            m.getHiddenApiRestrictions(),
                                            next);
                                };
                            }
                        });
        DexFile rewritten = rewriter.getDexFileRewriter().rewrite(input);
        List<ClassDef> classes = new ArrayList<>();
        for (ClassDef c : rewritten.getClasses())
            classes.add(com.android.tools.smali.dexlib2.immutable.ImmutableClassDef.of(c));
        if ("jed2".equals(mode)) {
            if (args.length != 4)
                throw new IllegalArgumentException("component helper dex required");
            DexFile helper = DexFileFactory.loadDexFile(args[3], Opcodes.getDefault());
            for (ClassDef c : helper.getClasses()) classes.add(c);
        }
        DexFileFactory.writeDexFile(args[2], new ImmutableDexFile(input.getOpcodes(), classes));
        if ("jed2".equals(mode)
                && (versionTransactions.get() != 1
                        || stopLogs.get() != 1
                        || contexts.get() != 1
                        || starts.get() != 1))
            throw new IllegalStateException(
                    "component patch targets mismatch version="
                            + versionTransactions
                            + " stop="
                            + stopLogs);
        if ("jed2".equals(mode) && exclusionMatchers.get() != 1)
            throw new IllegalStateException(
                    "exclusion matcher target mismatch: " + exclusionMatchers);
        int expected = "jed1".equals(mode) ? 3 : 10;
        if (changed.get() != expected || ("jed1".equals(mode) && timing.get() != 2))
            throw new IllegalStateException(
                    "patch target count mismatch methods=" + changed + " timing=" + timing);
        System.out.println(
                "DEX_PATCH_OK mode=" + mode + " methods=" + changed + " time_anchors=" + timing);
    }
}

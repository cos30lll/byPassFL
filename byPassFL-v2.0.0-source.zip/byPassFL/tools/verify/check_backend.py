#!/usr/bin/env python3
"""Verify exactly the bundled backend resources and their native content binding."""
from pathlib import Path
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.project import ROOT, manifest, properties, sha256
from backend.prepare_native import bind_native_assets


def check():
    config = properties()
    info = manifest()
    folder = ROOT / "app/src/main/assets/backend"
    assert info["target"] == config["targetPackage"]
    assert info["version_code"] == int(config["targetVersionCode"])
    assert info["entry"] == "ࢡࢡ.ࢡࢡࢡࢡ" and info["entry_method"] == "ࢡࢡ"
    assert info["component_version"] == int(config["componentVersion"])
    assert info["module_version"] == config["versionName"]
    assert info["exclusion_policy"] == "disabled"
    actual = {file.relative_to(folder).as_posix() for file in folder.rglob("*") if file.is_file() and file.name != "manifest.json"}
    assert actual == set(info["assets"]), "Backend contains undeclared or missing assets"
    for name, expected in info["assets"].items():
        assert not name.endswith(".xml") and "user" not in name.lower()
        data = (folder / name).read_bytes()
        assert len(data) == expected["bytes"], name
        assert sha256(data) == expected["sha256"], name
    assert info["native_binding"] == bind_native_assets(ROOT), "Native/component binding stale"
    with zipfile.ZipFile(folder / "jed2.apk") as archive:
        assert archive.testzip() is None
        dex = archive.read("classes.dex")
        assert b"Lcom/fl/bypass/component/ComponentVersion;" in dex
        assert b"Lcom/ds/ecmod/" not in dex
    return len(info["assets"])


if __name__ == "__main__":
    print("BACKEND_STATIC_OK assets=" + str(check()))

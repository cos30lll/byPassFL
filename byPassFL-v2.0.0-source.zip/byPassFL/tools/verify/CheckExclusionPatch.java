import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.iface.reference.*;
import com.android.tools.smali.dexlib2.iface.value.IntEncodedValue;

import java.nio.file.*;
import java.util.*;

/** Only inspect the changed matcher, two callers, and component version. No runtime objects. */
public final class CheckExclusionPatch {
    private static final String OWNER = "Lࢡ/Ԫ;";
    private static final String NAME = "ԩ";
    private static final List<String> PARAMS =
            Arrays.asList("Ljava/util/List;", "Ljava/lang/String;", "Ljava/lang/String;");

    static Method find(DexFile dex, String owner, String name, List<String> params) {
        for (ClassDef cls : dex.getClasses())
            if (owner.equals(cls.getType())) {
                for (Method method : cls.getMethods())
                    if (name.equals(method.getName()) && params.equals(method.getParameterTypes()))
                        return method;
            }
        throw new IllegalStateException("Missing ABI: " + owner + "->" + name + params);
    }

    static String fingerprint(Method method) {
        MethodImplementation body = method.getImplementation();
        StringBuilder out =
                new StringBuilder()
                        .append(method.getAccessFlags())
                        .append(':')
                        .append(body.getRegisterCount());
        for (Instruction insn : body.getInstructions()) {
            out.append('|').append(insn.getOpcode()).append(':').append(insn.getCodeUnits());
            if (insn instanceof FiveRegisterInstruction) {
                FiveRegisterInstruction x = (FiveRegisterInstruction) insn;
                out.append(':')
                        .append(x.getRegisterCount())
                        .append(':')
                        .append(x.getRegisterC())
                        .append(':')
                        .append(x.getRegisterD())
                        .append(':')
                        .append(x.getRegisterE())
                        .append(':')
                        .append(x.getRegisterF())
                        .append(':')
                        .append(x.getRegisterG());
            } else if (insn instanceof RegisterRangeInstruction) {
                RegisterRangeInstruction x = (RegisterRangeInstruction) insn;
                out.append(':')
                        .append(x.getStartRegister())
                        .append(':')
                        .append(x.getRegisterCount());
            } else if (insn instanceof ThreeRegisterInstruction) {
                ThreeRegisterInstruction x = (ThreeRegisterInstruction) insn;
                out.append(':')
                        .append(x.getRegisterA())
                        .append(':')
                        .append(x.getRegisterB())
                        .append(':')
                        .append(x.getRegisterC());
            } else if (insn instanceof TwoRegisterInstruction) {
                TwoRegisterInstruction x = (TwoRegisterInstruction) insn;
                out.append(':').append(x.getRegisterA()).append(':').append(x.getRegisterB());
            } else if (insn instanceof OneRegisterInstruction)
                out.append(':').append(((OneRegisterInstruction) insn).getRegisterA());
            if (insn instanceof ReferenceInstruction)
                out.append(':').append(((ReferenceInstruction) insn).getReference());
            if (insn instanceof DualReferenceInstruction)
                out.append(':').append(((DualReferenceInstruction) insn).getReference2());
            if (insn instanceof WideLiteralInstruction)
                out.append(':').append(((WideLiteralInstruction) insn).getWideLiteral());
            if (insn instanceof OffsetInstruction)
                out.append(':').append(((OffsetInstruction) insn).getCodeOffset());
        }
        for (TryBlock<? extends ExceptionHandler> block : body.getTryBlocks()) {
            out.append("|try:")
                    .append(block.getStartCodeAddress())
                    .append(':')
                    .append(block.getCodeUnitCount());
            for (ExceptionHandler handler : block.getExceptionHandlers())
                out.append(':')
                        .append(handler.getExceptionType())
                        .append(':')
                        .append(handler.getHandlerCodeAddress());
        }
        return out.toString();
    }

    static int countMatcherCalls(Method method) {
        int count = 0;
        for (Instruction insn : method.getImplementation().getInstructions()) {
            if (!(insn instanceof ReferenceInstruction)) continue;
            Reference ref = ((ReferenceInstruction) insn).getReference();
            if (ref instanceof MethodReference) {
                MethodReference target = (MethodReference) ref;
                if (OWNER.equals(target.getDefiningClass())
                        && NAME.equals(target.getName())
                        && PARAMS.equals(target.getParameterTypes())) count++;
            }
        }
        return count;
    }

    public static void main(String[] args) throws Exception {
        DexFile old = DexFileFactory.loadDexFile(args[0], Opcodes.getDefault());
        DexFile candidate = DexFileFactory.loadDexFile(args[1], Opcodes.getDefault());
        Method originalMatcher = find(old, OWNER, NAME, PARAMS);
        Method matcher = find(candidate, OWNER, NAME, PARAMS);
        if ((matcher.getAccessFlags() & 8) == 0 || !"Z".equals(matcher.getReturnType()))
            throw new IllegalStateException("Matcher ABI");
        List<Instruction> instructions = new ArrayList<>();
        for (Instruction insn : matcher.getImplementation().getInstructions())
            instructions.add(insn);
        if (instructions.size() != 2
                || instructions.get(0).getOpcode() != Opcode.CONST_4
                || ((NarrowLiteralInstruction) instructions.get(0)).getNarrowLiteral() != 1
                || instructions.get(1).getOpcode() != Opcode.RETURN
                || ((OneRegisterInstruction) instructions.get(0)).getRegisterA()
                        != ((OneRegisterInstruction) instructions.get(1)).getRegisterA()
                || !matcher.getImplementation().getTryBlocks().isEmpty())
            throw new IllegalStateException("Matcher must return true only");
        if (fingerprint(originalMatcher).equals(fingerprint(matcher)))
            throw new IllegalStateException("Matcher not changed");
        List<String> packageParams = Arrays.asList("Ljava/lang/String;", "Ljava/lang/String;");
        StringBuilder callers = new StringBuilder();
        int calls = 0;
        for (String owner : Arrays.asList("Lࢡ/ފ;", "Lࢡ/ޘ;")) {
            Method before = find(old, owner, "isAllowMockPackage", packageParams);
            Method after = find(candidate, owner, "isAllowMockPackage", packageParams);
            if (!fingerprint(before).equals(fingerprint(after)))
                throw new IllegalStateException("Caller changed: " + owner);
            calls += countMatcherCalls(after);
            if (callers.length() > 0) callers.append(", ");
            callers.append('"').append(owner).append('"');
        }
        if (calls != 2) throw new IllegalStateException("Shared matcher call paths changed");
        Method beforeSelection =
                find(
                        old,
                        "Lࢡ/ފ;",
                        "setAllowMockPackages",
                        Collections.singletonList("Ljava/util/List;"));
        Method afterSelection =
                find(
                        candidate,
                        "Lࢡ/ފ;",
                        "setAllowMockPackages",
                        Collections.singletonList("Ljava/util/List;"));
        if (!fingerprint(beforeSelection).equals(fingerprint(afterSelection)))
            throw new IllegalStateException("Manual app selection changed");
        boolean version5 = false;
        for (ClassDef cls : candidate.getClasses())
            if ("Lcom/fl/bypass/component/ComponentVersion;".equals(cls.getType())) {
                for (Field field : cls.getStaticFields())
                    if ("VERSION".equals(field.getName())
                            && field.getInitialValue() instanceof IntEncodedValue)
                        version5 = ((IntEncodedValue) field.getInitialValue()).getValue() == 5;
            }
        if (!version5) throw new IllegalStateException("Component version is not 5");
        String report =
                "{\n"
                    + "  \"module_version\": \"2.0.0\",\n"
                    + "  \"component_version\": 5,\n"
                    + "  \"matcher\":"
                    + " \"Lࢡ/Ԫ;->ԩ(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)Z\",\n"
                    + "  \"matcher_body\": \"CONST_4 1; RETURN\",\n"
                    + "  \"caller_bodies_unchanged\": ["
                        + callers
                        + "],\n"
                        + "  \"matcher_call_paths\": "
                        + calls
                        + ",\n"
                        + "  \"manual_application_selection\": \"preserved\",\n"
                        + "  \"result\": \"PASS\",\n"
                        + "  \"dynamic_validation\": \"pending user device test\"\n"
                        + "}\n";
        Files.write(Paths.get(args[2]), report.getBytes("UTF-8"));
        System.out.print(report);
    }
}

#!/usr/bin/env python3
"""Check final package identity, entrypoint, compile-only boundary, and backend assets."""
import argparse
from collections import Counter
import json
from pathlib import Path
import struct
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.dex import tables
from common.project import ROOT, properties, sha256, write_json


def binary_manifest(data):
    """Read relevant attributes from the APK's compiled Android manifest."""
    assert struct.unpack_from("<H", data)[0] == 3
    strings, attributes = [], {}
    offset = struct.unpack_from("<H", data, 2)[0]
    while offset < len(data):
        kind, header, size = struct.unpack_from("<HHI", data, offset)
        assert size >= header and offset + size <= len(data)
        if kind == 1:
            count, styles, flags, strings_start, style_start = struct.unpack_from("<IIIII", data, offset + 8)
            def length8(position):
                value = data[position]
                return (((value & 127) << 8) | data[position + 1], position + 2) if value & 128 else (value, position + 1)
            for index in range(count):
                position = offset + strings_start + struct.unpack_from("<I", data, offset + header + 4 * index)[0]
                if flags & 256:
                    _, position = length8(position)
                    length, position = length8(position)
                    strings.append(data[position:position + length].decode("utf-8"))
                else:
                    length = struct.unpack_from("<H", data, position)[0]
                    position += 2
                    if length & 32768:
                        length = ((length & 32767) << 16) | struct.unpack_from("<H", data, position)[0]
                        position += 2
                    strings.append(data[position:position + length * 2].decode("utf-16le"))
        elif kind == 258:
            element_index = struct.unpack_from("<I", data, offset + 20)[0]
            attr_start, attr_size, count = struct.unpack_from("<HHH", data, offset + 24)
            element = strings[element_index]
            values = {}
            for index in range(count):
                position = offset + 16 + attr_start + index * attr_size
                namespace, name, raw = struct.unpack_from("<III", data, position)
                value_type = data[position + 15]
                value = struct.unpack_from("<I", data, position + 16)[0]
                values[strings[name]] = strings[value] if value_type == 3 else value
            if element in {"manifest", "application", "activity"}:
                attributes.setdefault(element, []).append(values)
        offset += size
    return attributes


def verify(apk):
    config = properties()
    with zipfile.ZipFile(apk) as archive:
        assert archive.testzip() is None
        assert all(count == 1 for count in Counter(archive.namelist()).values()), "Duplicate ZIP entries"
        entry = archive.read("META-INF/xposed/java_init.list").decode().strip()
        scope = archive.read("META-INF/xposed/scope.list").decode().strip()
        props = dict(line.split("=", 1) for line in archive.read("META-INF/xposed/module.prop").decode().splitlines() if "=" in line)
        assert entry == config["entryClass"] and scope == config["targetPackage"]
        assert props["name"] == config["name"] and props["version"] == config["versionName"]
        assert props["versionCode"] == config["versionCode"] and props["minApiVersion"] == "102"
        android = binary_manifest(archive.read("AndroidManifest.xml"))
        manifest = android["manifest"][0]
        assert manifest["package"] == config["applicationId"]
        assert manifest["versionCode"] == int(config["versionCode"])
        assert manifest["versionName"] == config["versionName"]
        assert android["activity"][0]["name"] == "com.fl.bypass.ui.LauncherActivity"
        strings, classes = [], []
        for name in archive.namelist():
            if name.startswith("classes") and name.endswith(".dex") and "/" not in name:
                dex_strings, dex_classes = tables(archive.read(name))
                strings.extend(dex_strings)
                classes.extend(dex_classes)
        required = ["ByPassModule", "hook/HostHooks", "core/HookRegistry", "backend/BackendBootstrap", "backend/BackendAssets", "backend/PayloadHooks", "runtime/MockRuntimeHooks", "runtime/route/RouteHooks", "runtime/policy/PolicyHooks", "runtime/cell/CellSimulationHooks", "ui/LauncherActivity"]
        assert all("Lcom/fl/bypass/" + name + ";" in classes for name in required)
        assert not any(name.startswith(("Lio/github/libxposed/api/", "Lcom/ds/ecmod/")) for name in classes)
        assert not any("com.ds.ecmod" in value or "SchoolECMod" in value for value in strings)
        callers = archive.read("assets/pro_gate_callers.tsv").decode().splitlines()
        assert len(callers) == 56
        backend = json.loads(archive.read("assets/backend/manifest.json"))
        assert backend["component_version"] == int(config["componentVersion"])
        assert backend["module_version"] == config["versionName"]
        for name, expected in backend["assets"].items():
            data = archive.read("assets/backend/" + name)
            assert len(data) == expected["bytes"] and sha256(data) == expected["sha256"], name
        nested = archive.read("assets/backend/jed2.apk")
        import io
        with zipfile.ZipFile(io.BytesIO(nested)) as component:
            _, component_classes = tables(component.read("classes.dex"))
            assert "Lcom/fl/bypass/component/ComponentVersion;" in component_classes
            assert not any(name.startswith("Lcom/ds/ecmod/") for name in component_classes)
    result = {"apk": apk.name, "sha256": sha256(apk.read_bytes()), "bytes": apk.stat().st_size,
              "applicationId": manifest["package"], "version": config["versionName"], "entry": entry,
              "scope": scope, "dex_classes": len(classes), "backend_assets": len(backend["assets"]),
              "api_compile_only": True, "result": "PASS", "runtime_validation": "pending user device test"}
    write_json(ROOT / "build/reports/apk-verification.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("apk", type=Path)
    verify(parser.parse_args().apk)

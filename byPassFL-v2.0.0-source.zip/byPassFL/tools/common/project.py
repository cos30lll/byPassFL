"""Shared workspace paths, metadata, hashing, and SDK resolution."""
from pathlib import Path
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parents[2]
API_SHA256 = "423484a6e1807e7a423c4b88fcd8176d104318259d91791877fed88fe91479d0"


def properties():
    values = {}
    for line in (ROOT / "module.properties").read_text(encoding="utf-8").splitlines():
        if line and not line.startswith("#"):
            key, value = line.split("=", 1)
            values[key] = value
    return values


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def sdk_path():
    value = os.environ.get("BYPASSFL_SDK") or os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME")
    if not value:
        raise RuntimeError("Set BYPASSFL_SDK or ANDROID_SDK_ROOT to the Android SDK directory")
    return Path(value).expanduser().resolve()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def manifest():
    return json.loads((ROOT / "app/src/main/assets/backend/manifest.json").read_text(encoding="utf-8"))

"""Read DEX strings and class definitions without loading runtime objects."""
import struct


def tables(data):
    assert data[:4] == b"dex\n"
    count, offset = struct.unpack_from("<II", data, 56)
    strings = []
    for index in range(count):
        position = struct.unpack_from("<I", data, offset + index * 4)[0]
        while data[position] & 128:
            position += 1
        position += 1
        end = data.index(b"\0", position)
        strings.append(data[position:end].decode("utf-8", errors="replace"))
    count, offset = struct.unpack_from("<II", data, 64)
    types = [strings[struct.unpack_from("<I", data, offset + index * 4)[0]] for index in range(count)]
    count, offset = struct.unpack_from("<II", data, 96)
    classes = [types[struct.unpack_from("<I", data, offset + index * 32)[0]] for index in range(count)]
    return strings, classes

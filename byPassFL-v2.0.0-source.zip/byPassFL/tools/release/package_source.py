#!/usr/bin/env python3
"""Create an uploadable source archive from an explicit allowlist."""
import argparse
from pathlib import Path
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.project import ROOT, properties, sha256, write_json

TOP_LEVEL = [
    "README.md", "AGENTS.md", "CONTRIBUTING.md", "CHANGELOG.md", "THIRD_PARTY_NOTICES.md",
    ".gitignore", ".gitattributes", ".editorconfig", "module.properties", "settings.gradle",
    "build.gradle", "gradle.properties", "gradlew", "gradlew.bat", "build.sh",
]
FOLDERS = [
    ("app", {".gradle"}),
    ("app/src/main/java", {".java"}),
    ("app/src/main/res", {".xml"}),
    ("component/src/main/java", {".java"}),
    ("tools", {".py", ".java"}),
    ("docs", {".md", ".tsv"}),
    (".github", {".yml", ".md"}),
    ("gradle/wrapper", {".jar", ".properties", ".txt"}),
    ("libs/compile-only", {".aar", ".txt", ".md"}),
]


def source_files():
    files = {ROOT / name for name in TOP_LEVEL}
    files |= {ROOT / "app/src/main/AndroidManifest.xml", ROOT / "app/src/main/assets/pro_gate_callers.tsv",
              ROOT / "backend/input-manifest.json", ROOT / "backend/README.md"}
    for folder, extensions in FOLDERS:
        iterator = (ROOT / folder).glob("*") if folder == "app" else (ROOT / folder).rglob("*")
        files.update(file for file in iterator if file.is_file() and file.suffix in extensions
                     and not {"build", "__pycache__", "analysis", "backup", "logs"}.intersection(file.relative_to(ROOT).parts))
    if (ROOT / "LICENSE").is_file():
        files.add(ROOT / "LICENSE")
    return sorted(files)


def package(output):
    config = properties()
    files = source_files()
    records = []
    for file in files:
        relative = file.relative_to(ROOT).as_posix()
        assert file.is_file(), relative
        assert file.suffix not in {".keystore", ".jks", ".p12", ".pem", ".key", ".idsig", ".apk", ".dex", ".so"}, relative
        records.append({"path": relative, "bytes": file.stat().st_size, "sha256": sha256(file.read_bytes())})
    manifest = {"name": config["name"], "applicationId": config["applicationId"], "version": config["versionName"],
                "vendor_payload_included": False, "private_data_included": False, "files": records}
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest_file = output.parent / "source-manifest.json"
    write_json(manifest_file, manifest)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for file in files:
            entry = zipfile.ZipInfo(config["name"] + "/" + file.relative_to(ROOT).as_posix())
            entry.compress_type = zipfile.ZIP_DEFLATED
            mode = 0o755 if file.name in {"gradlew", "build.sh"} else 0o644
            entry.external_attr = (0o100000 | mode) << 16
            archive.writestr(entry, file.read_bytes())
        archive.write(manifest_file, config["name"] + "/source-manifest.json")
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(records) + 1
        for record in records:
            data = archive.read(config["name"] + "/" + record["path"])
            assert sha256(data) == record["sha256"], record["path"]
    digest = sha256(output.read_bytes())
    (output.parent / "SOURCE-SHA256.txt").write_text(digest + "  " + output.name + "\n")
    print("SOURCE_PACKAGE_OK files=" + str(len(records) + 1), output, digest)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    config = properties()
    package(parser.parse_args().output or ROOT / "dist" / (config["name"] + "-v" + config["versionName"] + "-source.zip"))